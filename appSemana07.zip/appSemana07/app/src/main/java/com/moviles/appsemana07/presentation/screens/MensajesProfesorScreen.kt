package com.moviles.appsemana07.presentation.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MensajesProfesorScreen(navController: NavController) {
    val fondoDegradado = Brush.linearGradient(colors = listOf(Color(0xFF8A2BE2), Color(0xFF4169E1)))
    val agrupados = ProfesorRepo.mensajes.groupBy { it.curso }

    Scaffold { padding ->
        Box(modifier = Modifier.fillMaxSize().background(fondoDegradado).padding(padding)) {
            Column(modifier = Modifier.fillMaxSize().padding(24.dp)) {
                EncabezadoConVolver(titulo = "Mensajes", navController = navController)
                Text("${ProfesorRepo.mensajes.size} mensajes de tus alumnos", color = Color(0xFFE0E0E0), fontSize = 14.sp)
                Spacer(modifier = Modifier.height(16.dp))

                LazyColumn(verticalArrangement = Arrangement.spacedBy(18.dp)) {
                    agrupados.forEach { (curso, mensajesCurso) ->
                        item {
                            Text(curso, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        }
                        items(mensajesCurso) { mensaje ->
                            Card(
                                shape = RoundedCornerShape(14.dp),
                                colors = CardDefaults.cardColors(containerColor = Color.White),
                                elevation = CardDefaults.cardElevation(3.dp),
                                modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                            ) {
                                Row(modifier = Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier.size(36.dp).clip(CircleShape).background(Color(0xFFE3E0FF)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            mensaje.alumno.split(" ").take(2).joinToString("") { it.take(1) },
                                            fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF6A3DE8)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(mensaje.alumno, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFF222222))
                                        Text(mensaje.mensaje, fontSize = 12.sp, color = Color.Gray, maxLines = 1)
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(mensaje.hora, fontSize = 11.sp, color = Color.Gray)
                                }
                            }
                        }
                    }
                    item { Spacer(modifier = Modifier.height(4.dp)) }
                }
            }
        }
    }
}
