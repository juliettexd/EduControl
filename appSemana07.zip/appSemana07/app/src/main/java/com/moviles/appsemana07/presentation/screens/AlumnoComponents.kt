package com.moviles.appsemana07.presentation.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController

data class ItemNavAlumno(val ruta: String, val icono: ImageVector, val etiqueta: String)

val itemsNavAlumno = listOf(
    ItemNavAlumno("alumno", Icons.Filled.Home, "Inicio"),
    ItemNavAlumno("cursosAlumno", Icons.Filled.MenuBook, "Cursos"),
    ItemNavAlumno("horarioAlumno", Icons.Filled.CalendarMonth, "Horario"),
    ItemNavAlumno("notasAlumno", Icons.Filled.TrendingUp, "Notas"),
    ItemNavAlumno("perfilAlumno", Icons.Filled.Person, "Perfil")
)

@Composable
fun BottomNavAlumno(navController: NavController, rutaActual: String) {
    NavigationBar(containerColor = Color.White) {
        itemsNavAlumno.forEach { item ->
            val seleccionado = item.ruta == rutaActual
            NavigationBarItem(
                selected = seleccionado,
                onClick = {
                    if (!seleccionado) {
                        navController.navigate(item.ruta) {
                            popUpTo("alumno") { inclusive = false }
                            launchSingleTop = true
                        }
                    }
                },
                icon = { Icon(imageVector = item.icono, contentDescription = item.etiqueta) },
                label = { Text(text = item.etiqueta, fontSize = 11.sp) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = Color(0xFF2962FF),
                    selectedTextColor = Color(0xFF2962FF),
                    indicatorColor = Color(0xFFE8EEFF),
                    unselectedIconColor = Color.Gray,
                    unselectedTextColor = Color.Gray
                )
            )
        }
    }
}

@Composable
fun EncabezadoConVolver(titulo: String, navController: NavController) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = Icons.Filled.ArrowBack,
            contentDescription = "Volver",
            tint = Color.White,
            modifier = Modifier
                .clickable { navController.popBackStack() }
                .padding(end = 14.dp)
        )
        Text(
            text = titulo,
            color = Color.White,
            fontSize = 26.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun EncabezadoPestana(titulo: String, subtitulo: String? = null, navController: NavController, mostrarVolver: Boolean) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (mostrarVolver) {
            Icon(
                imageVector = Icons.Filled.ArrowBack,
                contentDescription = "Volver",
                tint = Color.White,
                modifier = Modifier
                    .clickable { navController.popBackStack() }
                    .padding(end = 12.dp)
            )
        }
        Column {
            Text(text = titulo, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
            if (subtitulo != null) {
                Text(text = subtitulo, color = Color(0xFFE0E0E0), fontSize = 13.sp)
            }
        }
    }
}
