package com.moviles.appsemana07.presentation.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AlumnosProfesorScreen(navController: NavController) {
    val fondoDegradado = Brush.linearGradient(colors = listOf(Color(0xFF8A2BE2), Color(0xFF4169E1)))

    Scaffold(
        bottomBar = { BottomNavProfesor(navController = navController, rutaActual = "alumnosProfesor") }
    ) { padding ->
        Box(modifier = Modifier.fillMaxSize().background(fondoDegradado).padding(padding)) {
            Column(modifier = Modifier.fillMaxSize().padding(24.dp)) {
                EncabezadoPestana(
                    titulo = "Mis Alumnos",
                    subtitulo = "${ProfesorRepo.totalAlumnos} alumnos en ${ProfesorRepo.cursos.size} cursos",
                    navController = navController,
                    mostrarVolver = true
                )
                Spacer(modifier = Modifier.height(16.dp))

                LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(ProfesorRepo.cursos) { curso ->
                        var expandido by remember { mutableStateOf(false) }

                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            elevation = CardDefaults.cardElevation(4.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { expandido = !expandido },
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(curso.nombre, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Color(0xFF222222))
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Filled.Group, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(14.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("${curso.totalAlumnos} alumnos", fontSize = 12.sp, color = Color.Gray)
                                            Spacer(modifier = Modifier.width(12.dp))
                                            Icon(Icons.Filled.Schedule, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(14.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(curso.horarioTexto, fontSize = 12.sp, color = Color.Gray)
                                        }
                                    }
                                    Icon(
                                        imageVector = if (expandido) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore,
                                        contentDescription = if (expandido) "Ocultar alumnos" else "Ver alumnos",
                                        tint = Color(0xFF2962FF)
                                    )
                                }

                                if (expandido) {
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Divider(color = Color(0xFFEFEFEF))
                                    Spacer(modifier = Modifier.height(8.dp))
                                    curso.alumnos.forEach { alumno ->
                                        Row(
                                            modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .size(32.dp)
                                                    .clip(CircleShape)
                                                    .background(Color(0xFF6A3DE8).copy(alpha = 0.12f)),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Text(
                                                    alumno.nombre.split(" ").take(2).joinToString("") { it.take(1) }.uppercase(),
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color(0xFF6A3DE8)
                                                )
                                            }
                                            Spacer(modifier = Modifier.width(10.dp))
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(alumno.nombre, fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color(0xFF222222))
                                                Text(
                                                    if (alumno.asistio) "Asistencia al día" else "Con inasistencias",
                                                    fontSize = 11.sp,
                                                    color = if (alumno.asistio) Color(0xFF00B4A6) else Color(0xFFD32F2F)
                                                )
                                            }
                                            Text(
                                                "Prom: %.1f".format(alumno.promedio),
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Color(0xFF2962FF)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                    item { Spacer(modifier = Modifier.height(4.dp)) }
                }
            }
        }
    }
}
