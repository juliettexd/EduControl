package com.moviles.appsemana07.presentation.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AlumnoDashboardScreen(navController: NavController) {

    val fondoDegradado = Brush.linearGradient(
        colors = listOf(Color(0xFF8A2BE2), Color(0xFF4169E1))
    )

    Scaffold(
        bottomBar = { BottomNavAlumno(navController = navController, rutaActual = "alumno") }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(fondoDegradado)
                .padding(padding)
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = "¡Hola, Juan!", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                    Text(text = AlumnoRepo.cursos.first().nombre, color = Color(0xFFE0E0E0), fontSize = 14.sp)
                }
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        TarjetaEstadistica(
                            modifier = Modifier.weight(1f),
                            icono = Icons.Filled.MenuBook,
                            valor = "${AlumnoRepo.cursos.size}",
                            etiqueta = "Mis Cursos"
                        ) {
                            navController.navigate("cursosAlumno") {
                                popUpTo("alumno"); launchSingleTop = true
                            }
                        }
                        TarjetaEstadistica(
                            modifier = Modifier.weight(1f),
                            icono = Icons.Filled.TrendingUp,
                            valor = String.format("%.1f", AlumnoRepo.promedioGeneral),
                            etiqueta = "Promedio"
                        ) {
                            navController.navigate("notasAlumno") {
                                popUpTo("alumno"); launchSingleTop = true
                            }
                        }
                    }
                }
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        TarjetaEstadistica(
                            modifier = Modifier.weight(1f),
                            icono = Icons.Filled.CheckCircle,
                            valor = "${AlumnoRepo.porcentajeAsistencia}%",
                            etiqueta = "Asistencia"
                        ) {
                            navController.navigate("horarioAlumno") {
                                popUpTo("alumno"); launchSingleTop = true
                            }
                        }
                        TarjetaEstadistica(
                            modifier = Modifier.weight(1f),
                            icono = Icons.Filled.Notifications,
                            valor = "${AlumnoRepo.avisos.size}",
                            etiqueta = "Avisos"
                        ) {
                            navController.navigate("avisosAlumno")
                        }
                    }
                }
                item {
                    Spacer(modifier = Modifier.height(8.dp))
                    SeccionConVerTodo(titulo = "Clases de Hoy") {
                        navController.navigate("horarioAlumno") {
                            popUpTo("alumno"); launchSingleTop = true
                        }
                    }
                }
                if (AlumnoRepo.clasesDeHoy.isEmpty()) {
                    item {
                        TarjetaBlanca {
                            Text("No tienes clases programadas para hoy.", color = Color.Gray, fontSize = 13.sp)
                        }
                    }
                } else {
                    items(AlumnoRepo.clasesDeHoy) { clase ->
                        TarjetaBlanca(
                            onClick = {
                                navController.navigate("horarioAlumno") {
                                    popUpTo("alumno"); launchSingleTop = true
                                }
                            }
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.Schedule, contentDescription = null, tint = Color(0xFF6A3DE8))
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(clase.curso, fontWeight = FontWeight.Bold, color = Color(0xFF222222))
                                    Text("${clase.horaInicio} - ${clase.horaFin}", fontSize = 12.sp, color = Color.Gray)
                                    Text(clase.aula, fontSize = 12.sp, color = Color.Gray)
                                }
                            }
                        }
                    }
                }
                item {
                    Spacer(modifier = Modifier.height(8.dp))
                    SeccionConVerTodo(titulo = "Avisos Recientes") {
                        navController.navigate("avisosAlumno")
                    }
                }
                items(AlumnoRepo.avisos.take(2)) { aviso ->
                    TarjetaBlanca(onClick = { navController.navigate("avisosAlumno") }) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(aviso.titulo, fontWeight = FontWeight.Bold, color = Color(0xFF222222))
                                Text(aviso.curso, fontSize = 12.sp, color = Color.Gray)
                            }
                            Text(aviso.fecha, fontSize = 12.sp, color = Color.Gray)
                        }
                    }
                }

                item { Spacer(modifier = Modifier.height(8.dp)) }
            }
        }
    }
}

@Composable
private fun TarjetaEstadistica(
    modifier: Modifier = Modifier,
    icono: ImageVector,
    valor: String,
    etiqueta: String,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(6.dp),
        modifier = modifier.clickable { onClick() }
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Icon(icono, contentDescription = etiqueta, tint = Color(0xFF6A3DE8))
            Spacer(modifier = Modifier.height(8.dp))
            Text(valor, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color(0xFF222222))
            Text(etiqueta, fontSize = 12.sp, color = Color.Gray)
        }
    }
}

@Composable
private fun SeccionConVerTodo(titulo: String, onVerTodo: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(titulo, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Text(
            "Ver todo",
            color = Color(0xFFE0E0E0),
            fontSize = 13.sp,
            modifier = Modifier.clickable { onVerTodo() }
        )
    }
}

@Composable
private fun TarjetaBlanca(onClick: (() -> Unit)? = null, contenido: @Composable ColumnScope.() -> Unit) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(4.dp),
        modifier = Modifier
            .fillMaxWidth()
            .let { if (onClick != null) it.clickable { onClick() } else it }
    ) {
        Column(modifier = Modifier.padding(16.dp), content = contenido)
    }
}
