package com.moviles.appsemana07.di

import android.content.Context
import androidx.room.Room
import com.moviles.appsemana07.data.local.db.AppDatabase
import com.moviles.appsemana07.data.repository.UsuarioRepositoryImpl
import com.moviles.appsemana07.domain.repository.UsuarioRepository
import com.moviles.appsemana07.domain.usecase.ActualizarUsuarioUseCase
import com.moviles.appsemana07.domain.usecase.AgregarUsuarioUseCase
import com.moviles.appsemana07.domain.usecase.EliminarUsuarioUseCase
import com.moviles.appsemana07.domain.usecase.GetUsuarioByIdUseCase
import com.moviles.appsemana07.domain.usecase.GetUsuarioUseCase
import com.moviles.appsemana07.domain.usecase.UsuarioUseCase
import com.moviles.appsemana07.presentation.viewmodel.UsuarioViewModel
// ESTOS 3 IMPORTS ADICIONALES MATAN EL ERROR:
import com.moviles.appsemana07.data.remote.EduControlApiService
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object AppModule {

    private const val BASE_URL = "https://5pms3scg4k.execute-api.us-east-1.amazonaws.com/default/"

    val apiService: EduControlApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(EduControlApiService::class.java)
    }
    private fun provideDatabase(context: Context): AppDatabase{
        return Room.databaseBuilder(context, AppDatabase::class.java,"usuarios_db").build()
    }
    private fun provideUsuarioDao(context: Context) =
        provideDatabase(context).usuarioDao()

    //Repositorios
    private fun provideUsuarioRepository(context: Context): UsuarioRepository{
        return UsuarioRepositoryImpl(provideUsuarioDao(context))
    }

    //UseCase
    fun provideUsuarioUseCases(context: Context): UsuarioUseCase{
        val repository = provideUsuarioRepository(context)
        return UsuarioUseCase(
            agregarUsuario = AgregarUsuarioUseCase(repository),
            actualizarUsuario = ActualizarUsuarioUseCase(repository),
            eliminarUsuario = EliminarUsuarioUseCase(repository),
            getUsuarios = GetUsuarioUseCase(repository),
            getUsuarioById = GetUsuarioByIdUseCase(repository)
        )
    }

    fun provideUsuarioViewModel(context: Context): UsuarioViewModel{
        return UsuarioViewModel(provideUsuarioUseCases(context))
    }
}