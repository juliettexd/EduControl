package com.moviles.appsemana07.presentation.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
data class ItemNavProfesor(val ruta: String, val icono: ImageVector, val etiqueta: String)

val itemsNavProfesor = listOf(
    ItemNavProfesor("profesor", Icons.Filled.Home, "Inicio"),
    ItemNavProfesor("cursosProfesor", Icons.Filled.MenuBook, "Cursos"),
    ItemNavProfesor("notasProfesor", Icons.Filled.Assignment, "Notas"),
    ItemNavProfesor("avisosProfesor", Icons.Filled.Campaign, "Avisos"),
    ItemNavProfesor("perfilProfesor", Icons.Filled.Person, "Perfil")
)

@Composable
fun BottomNavProfesor(navController: NavController, rutaActual: String) {
    NavigationBar(containerColor = Color.White) {
        itemsNavProfesor.forEach { item ->
            val seleccionado = item.ruta == rutaActual
            NavigationBarItem(
                selected = seleccionado,
                onClick = {
                    if (!seleccionado) {
                        navController.navigate(item.ruta) {
                            popUpTo("profesor") { inclusive = false }
                            launchSingleTop = true
                        }
                    }
                },
                icon = { Icon(item.icono, contentDescription = item.etiqueta) },
                label = { Text(text = item.etiqueta, fontSize = 11.sp) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = Color(0xFF2962FF),
                    selectedTextColor = Color(0xFF2962FF),
                    indicatorColor = Color(0xFFE8EEFF),
                    unselectedIconColor = Color.Gray,
                    unselectedTextColor = Color.Gray
                )
            )
        }
    }
}

@Composable
fun TarjetaEstadisticaProfesor(
    modifier: Modifier = Modifier,
    icono: ImageVector,
    valor: String,
    etiqueta: String,
    color: Color = Color(0xFF2962FF),
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(6.dp),
        modifier = modifier.clickable { onClick() }
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .background(color.copy(alpha = 0.15f), RoundedCornerShape(10.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icono, contentDescription = null, tint = color, modifier = Modifier.size(18.dp))
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(valor, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color(0xFF222222))
            Text(etiqueta, fontSize = 12.sp, color = Color.Gray)
        }
    }
}

@Composable
fun TarjetaBlancaProfesor(onClick: (() -> Unit)? = null, contenido: @Composable ColumnScope.() -> Unit) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(4.dp),
        modifier = Modifier
            .fillMaxWidth()
            .let { if (onClick != null) it.clickable { onClick() } else it }
    ) {
        Column(modifier = Modifier.padding(18.dp), content = contenido)
    }
}
