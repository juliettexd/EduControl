package com.moviles.appsemana07.domain.model

enum class EstadoMatricula { CONFIRMADA, PENDIENTE }

data class Matricula(
    val id: Int,
    val alumno: String,
    val curso: String,
    val fecha: String,
    val estado: EstadoMatricula
)
