package com.moviles.appsemana07.presentation.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RegistrarAsistenciaScreen(navController: NavController, cursoId: Int) {
    val fondoDegradado = Brush.linearGradient(colors = listOf(Color(0xFF8A2BE2), Color(0xFF4169E1)))
    val curso = ProfesorRepo.cursoPorId(cursoId) ?: return

    Scaffold { padding ->
        Box(modifier = Modifier.fillMaxSize().background(fondoDegradado).padding(padding)) {
            Column(modifier = Modifier.fillMaxSize().padding(24.dp)) {
                EncabezadoConVolver(titulo = "Registrar Asistencia", navController = navController)
                Spacer(modifier = Modifier.height(8.dp))

                Text("Curso", color = Color(0xFFE0E0E0), fontSize = 13.sp)
                Spacer(modifier = Modifier.height(6.dp))
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(curso.nombre, fontWeight = FontWeight.Bold, modifier = Modifier.padding(16.dp))
                }

                Spacer(modifier = Modifier.height(14.dp))
                Text("Fecha", color = Color(0xFFE0E0E0), fontSize = 13.sp)
                Spacer(modifier = Modifier.height(6.dp))
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.DateRange, contentDescription = null, tint = Color.Gray)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("13/05/2026", fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
                val presentes = curso.alumnos.count { it.asistio }
                val total = curso.alumnos.size
                val porcentaje = if (total == 0) 0 else (presentes * 100 / total)
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(4.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Asistencia: $presentes/$total", fontWeight = FontWeight.Bold, color = Color(0xFF222222))
                            Text("$porcentaje%", fontWeight = FontWeight.Bold, color = Color(0xFF2962FF))
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        LinearProgressIndicator(
                            progress = porcentaje / 100f,
                            modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(50)),
                            color = Color(0xFF00B4A6),
                            trackColor = Color(0xFFEFEFEF)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(curso.alumnos, key = { it.id }) { alumno ->
                        Card(
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            elevation = CardDefaults.cardElevation(2.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(38.dp)
                                            .clip(CircleShape)
                                            .background(Color(0xFFE3E0FF)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            alumno.nombre.split(" ").take(2).joinToString("") { it.take(1) },
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFF6A3DE8)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Text(alumno.nombre, fontWeight = FontWeight.Bold, color = Color(0xFF222222))
                                }
                                Icon(
                                    imageVector = if (alumno.asistio) Icons.Filled.CheckCircle else Icons.Filled.Cancel,
                                    contentDescription = if (alumno.asistio) "Presente" else "Falta",
                                    tint = if (alumno.asistio) Color(0xFF2E7D32) else Color(0xFFE53935),
                                    modifier = Modifier
                                        .size(28.dp)
                                        .clickable { alumno.asistio = !alumno.asistio }
                                )
                            }
                        }
                    }
                    item { Spacer(modifier = Modifier.height(4.dp)) }
                }

                Spacer(modifier = Modifier.height(8.dp))
                Button(
                    onClick = {
                        curso.porcentajeAsistencia.value = porcentaje
                        curso.asistenciaTomadaHoy.value = true
                        navController.popBackStack()
                    },
                    modifier = Modifier.fillMaxWidth().height(50.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6A3DE8))
                ) {
                    Text("Guardar Asistencia", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
