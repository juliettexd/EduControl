package com.moviles.appsemana07.domain.model

data class Curso(
    val nombre: String,
    val duracion: String,
    val horario: String,
    val profesor: String = "Sin asignar"
)
