package com.moviles.appsemana07.presentation.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AvisosProfesorScreen(navController: NavController) {
    val fondoDegradado = Brush.linearGradient(colors = listOf(Color(0xFF8A2BE2), Color(0xFF4169E1)))
    var avisoEditando by remember { mutableStateOf<AvisoProfesor?>(null) }
    var mostrarDialogo by remember { mutableStateOf(false) }

    Scaffold(
        bottomBar = { BottomNavProfesor(navController = navController, rutaActual = "avisosProfesor") }
    ) { padding ->
        Box(modifier = Modifier.fillMaxSize().background(fondoDegradado).padding(padding)) {
            Column(modifier = Modifier.fillMaxSize().padding(24.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "Avisos Académicos",
                        color = Color.White,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.weight(1f)
                    )
                    Button(
                        onClick = {
                            avisoEditando = null
                            mostrarDialogo = true
                        },
                        shape = RoundedCornerShape(50),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6A3DE8)),
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
                    ) {
                        Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Nuevo", fontSize = 13.sp)
                    }
                }
                Text("Comunicados a estudiantes", color = Color(0xFFE0E0E0), fontSize = 13.sp)
                Spacer(modifier = Modifier.height(16.dp))

                LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(ProfesorRepo.avisos, key = { it.id }) { aviso ->
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            elevation = CardDefaults.cardElevation(4.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(18.dp)) {
                                Text(aviso.titulo, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color(0xFF2962FF))
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(aviso.mensaje, fontSize = 13.sp, color = Color.DarkGray)
                                Spacer(modifier = Modifier.height(10.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Filled.Visibility, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("${aviso.vistas} vistas", fontSize = 11.sp, color = Color.Gray)
                                    }
                                    Text(aviso.fecha, fontSize = 11.sp, color = Color.Gray)
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .background(Color(0xFFF3E5F5), RoundedCornerShape(50))
                                            .padding(horizontal = 10.dp, vertical = 4.dp)
                                    ) {
                                        Text(aviso.curso, fontSize = 11.sp, color = Color(0xFF6A3DE8))
                                    }
                                    TextButton(onClick = {
                                        avisoEditando = aviso
                                        mostrarDialogo = true
                                    }) {
                                        Icon(Icons.Filled.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Editar", fontSize = 13.sp)
                                    }
                                }
                            }
                        }
                    }
                    item { Spacer(modifier = Modifier.height(4.dp)) }
                }
            }

            if (mostrarDialogo) {
                DialogoAviso(
                    aviso = avisoEditando,
                    onDismiss = { mostrarDialogo = false },
                    onGuardar = { titulo, mensaje, curso ->
                        val actual = avisoEditando
                        if (actual != null) {
                            actual.titulo = titulo
                            actual.mensaje = mensaje
                            actual.curso = curso
                        } else {
                            ProfesorRepo.avisos.add(
                                0,
                                AvisoProfesor(
                                    id = (ProfesorRepo.avisos.maxOfOrNull { it.id } ?: 0) + 1,
                                    titulo = titulo,
                                    mensaje = mensaje,
                                    curso = curso,
                                    fecha = "Hoy",
                                    vistas = 0
                                )
                            )
                        }
                        mostrarDialogo = false
                    }
                )
            }
        }
    }
}

@Composable
private fun DialogoAviso(
    aviso: AvisoProfesor?,
    onDismiss: () -> Unit,
    onGuardar: (String, String, String) -> Unit
) {
    var titulo by remember { mutableStateOf(aviso?.titulo ?: "") }
    var mensaje by remember { mutableStateOf(aviso?.mensaje ?: "") }
    var curso by remember { mutableStateOf(aviso?.curso ?: ProfesorRepo.cursos.first().nombre) }
    var menuAbierto by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (aviso == null) "Nuevo Aviso" else "Editar Aviso") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = titulo, onValueChange = { titulo = it },
                    label = { Text("Título") }, singleLine = true, modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = mensaje, onValueChange = { mensaje = it },
                    label = { Text("Mensaje") }, minLines = 3, modifier = Modifier.fillMaxWidth()
                )
                Box {
                    OutlinedTextField(
                        value = curso, onValueChange = {}, readOnly = true,
                        label = { Text("Curso") },
                        trailingIcon = { Icon(Icons.Filled.ArrowDropDown, contentDescription = null) },
                        modifier = Modifier.fillMaxWidth().clickable2 { menuAbierto = true }
                    )
                    DropdownMenu(expanded = menuAbierto, onDismissRequest = { menuAbierto = false }) {
                        ProfesorRepo.cursos.forEach {
                            DropdownMenuItem(text = { Text(it.nombre) }, onClick = {
                                curso = it.nombre
                                menuAbierto = false
                            })
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { if (titulo.isNotBlank()) onGuardar(titulo, mensaje, curso) }) {
                Text("Guardar")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancelar") }
        }
    )
}

private fun Modifier.clickable2(onClick: () -> Unit): Modifier =
    this.clickable(onClick = onClick)
