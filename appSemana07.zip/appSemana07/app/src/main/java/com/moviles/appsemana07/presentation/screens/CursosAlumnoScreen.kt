package com.moviles.appsemana07.presentation.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CursosAlumnoScreen(navController: NavController) {
    val fondoDegradado = Brush.linearGradient(colors = listOf(Color(0xFF8A2BE2), Color(0xFF4169E1)))

    Scaffold(
        bottomBar = { BottomNavAlumno(navController = navController, rutaActual = "cursosAlumno") }
    ) { padding ->
        Box(modifier = Modifier.fillMaxSize().background(fondoDegradado).padding(padding)) {
            Column(modifier = Modifier.fillMaxSize().padding(24.dp)) {
                EncabezadoPestana(
                    titulo = "Mis Cursos",
                    subtitulo = "${AlumnoRepo.cursos.size} cursos matriculados",
                    navController = navController,
                    mostrarVolver = true
                )
                Spacer(modifier = Modifier.height(16.dp))

                LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(AlumnoRepo.cursos) { curso ->
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            elevation = CardDefaults.cardElevation(4.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(20.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.Top
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(curso.nombre, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color(0xFF222222))
                                        Text(curso.profesor, fontSize = 13.sp, color = Color.Gray)
                                    }
                                    Box(
                                        modifier = Modifier
                                            .background(Color(0xFFE8F5E9), RoundedCornerShape(50))
                                            .padding(horizontal = 10.dp, vertical = 4.dp)
                                    ) {
                                        Text(
                                            text = "%.0f".format(curso.notaGeneral),
                                            color = Color(0xFF2E7D32),
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(20.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Filled.Schedule, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(14.dp))
                                    Text(curso.horarioTexto, fontSize = 12.sp, color = Color.Gray)
                                    Icon(Icons.Filled.MenuBook, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(14.dp))
                                    Text("${curso.creditos} créditos", fontSize = 12.sp, color = Color.Gray)
                                }

                                Spacer(modifier = Modifier.height(12.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("Progreso del curso", fontSize = 12.sp, color = Color.Gray)
                                    Text("${curso.progreso}%", fontSize = 12.sp, color = Color.Gray)
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                LinearProgressIndicator(
                                    progress = curso.progreso / 100f,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(6.dp)
                                        .clip(RoundedCornerShape(50)),
                                    color = Color(0xFF6A3DE8),
                                    trackColor = Color(0xFFEFEFEF)
                                )
                            }
                        }
                    }
                    item { Spacer(modifier = Modifier.height(4.dp)) }
                }
            }
        }
    }
}
