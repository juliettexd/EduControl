package com.moviles.appsemana07.presentation.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotasAlumnoScreen(navController: NavController) {
    val fondoDegradado = Brush.linearGradient(colors = listOf(Color(0xFF8A2BE2), Color(0xFF4169E1)))

    Scaffold(
        bottomBar = { BottomNavAlumno(navController = navController, rutaActual = "notasAlumno") }
    ) { padding ->
        Box(modifier = Modifier.fillMaxSize().background(fondoDegradado).padding(padding)) {
            Column(modifier = Modifier.fillMaxSize().padding(24.dp)) {
                EncabezadoPestana(titulo = "Mis Notas", navController = navController, mostrarVolver = true)
                Spacer(modifier = Modifier.height(16.dp))

                LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    item {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            elevation = CardDefaults.cardElevation(4.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(20.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(44.dp)
                                        .background(Color(0xFFFFF3E0), RoundedCornerShape(12.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Filled.EmojiEvents, contentDescription = null, tint = Color(0xFFFF9800))
                                }
                                Spacer(modifier = Modifier.width(14.dp))
                                Column {
                                    Text("Promedio General", fontSize = 13.sp, color = Color.Gray)
                                    Text(
                                        text = String.format("%.1f", AlumnoRepo.promedioGeneral),
                                        fontSize = 24.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF2962FF)
                                    )
                                }
                            }
                        }
                    }

                    items(AlumnoRepo.cursos) { curso ->
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            elevation = CardDefaults.cardElevation(4.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(20.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(curso.nombre, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color(0xFF222222))
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Filled.TrendingUp, contentDescription = null, tint = Color(0xFF2962FF), modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            String.format("%.1f", curso.notaGeneral),
                                            color = Color(0xFF2962FF),
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(12.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    NotaParcial("Examen 1 (30%)", curso.examen1)
                                    NotaParcial("Examen 2 (30%)", curso.examen2)
                                    NotaParcial("${curso.terceraEvaluacionNombre} (40%)", curso.terceraEvaluacionValor)
                                }
                            }
                        }
                    }
                    item { Spacer(modifier = Modifier.height(4.dp)) }
                }
            }
        }
    }
}

@Composable
private fun NotaParcial(etiqueta: String, valor: Int) {
    Column(horizontalAlignment = Alignment.Start) {
        Text(etiqueta, fontSize = 11.sp, color = Color.Gray)
        Spacer(modifier = Modifier.height(4.dp))
        Box(
            modifier = Modifier
                .background(Color(0xFFE3F2FD), RoundedCornerShape(50))
                .padding(horizontal = 10.dp, vertical = 3.dp)
        ) {
            Text("$valor", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFF2962FF))
        }
    }
}
