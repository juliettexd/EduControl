package com.moviles.appsemana07.presentation.screens

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
data class ItemNavAdmin(val ruta: String, val icono: ImageVector, val etiqueta: String)

val itemsNavAdmin = listOf(
    ItemNavAdmin("adminMenu", Icons.Filled.Home, "Inicio"),
    ItemNavAdmin("gestionAlumnos", Icons.Filled.Groups, "Alumnos"),
    ItemNavAdmin("gestionCursos", Icons.Filled.MenuBook, "Cursos"),
    ItemNavAdmin("reportesScreen", Icons.Filled.Assessment, "Reportes"),
    ItemNavAdmin("perfilAdmin", Icons.Filled.Person, "Perfil")
)

@Composable
fun BottomNavAdmin(navController: NavController, rutaActual: String) {
    NavigationBar(containerColor = Color.White) {
        itemsNavAdmin.forEach { item ->
            val seleccionado = item.ruta == rutaActual
            NavigationBarItem(
                selected = seleccionado,
                onClick = {
                    if (!seleccionado) {
                        navController.navigate(item.ruta) {
                            popUpTo("adminMenu") { inclusive = false }
                            launchSingleTop = true
                        }
                    }
                },
                icon = { Icon(imageVector = item.icono, contentDescription = item.etiqueta) },
                label = { Text(text = item.etiqueta, fontSize = 11.sp) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = Color(0xFF2962FF),
                    selectedTextColor = Color(0xFF2962FF),
                    indicatorColor = Color(0xFFE8EEFF),
                    unselectedIconColor = Color.Gray,
                    unselectedTextColor = Color.Gray
                )
            )
        }
    }
}
