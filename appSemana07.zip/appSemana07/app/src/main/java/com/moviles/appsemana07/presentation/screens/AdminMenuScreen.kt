package com.moviles.appsemana07.presentation.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminMenuScreen(navController: NavController) {
    val fondoDegradado = Brush.linearGradient(colors = listOf(Color(0xFF8A2BE2), Color(0xFF4169E1)))
    val scrollState = rememberScrollState()

    Scaffold(
        bottomBar = { BottomNavAdmin(navController = navController, rutaActual = "adminMenu") }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(fondoDegradado)
                .padding(paddingValues)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(scrollState)
                    .padding(24.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Spacer(modifier = Modifier.height(8.dp))
                Text("Panel Administrativo", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                Text("Gestión integral del instituto", color = Color(0xFFE0E0E0), fontSize = 14.sp)

                Spacer(modifier = Modifier.height(4.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                    StatCard(
                        icono = Icons.Filled.Group,
                        valor = "${AdminRepo.alumnos.size}",
                        etiqueta = "Total Alumnos",
                        color = Color(0xFF2962FF),
                        modifier = Modifier.weight(1f)
                    ) { navController.navigate("gestionAlumnos") }
                    StatCard(
                        icono = Icons.Filled.School,
                        valor = "${AdminRepo.profesores.size}",
                        etiqueta = "Total Profesores",
                        color = Color(0xFFAA00FF),
                        modifier = Modifier.weight(1f)
                    ) { navController.navigate("gestionProfesores") }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                    StatCard(
                        icono = Icons.Filled.MenuBook,
                        valor = "${AdminRepo.cursos.size}",
                        etiqueta = "Cursos Activos",
                        color = Color(0xFF00B4A6),
                        modifier = Modifier.weight(1f)
                    ) { navController.navigate("gestionCursos") }
                    StatCard(
                        icono = Icons.Filled.HowToReg,
                        valor = "${AdminRepo.matriculas.size}",
                        etiqueta = "Matrículas",
                        color = Color(0xFFFF6D00),
                        modifier = Modifier.weight(1f)
                    ) { navController.navigate("gestionMatriculas") }
                }

                Spacer(modifier = Modifier.height(4.dp))

                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFF6D00)),
                    elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { navController.navigate("gestionMatriculas") }
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(20.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Matrículas pendientes por revisar", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            Text(
                                "${AdminRepo.matriculas.count { it.estado.name == "PENDIENTE" }} solicitudes esperando confirmación",
                                color = Color(0xFFFFE0CC),
                                fontSize = 13.sp
                            )
                        }
                        Icon(Icons.Filled.ArrowForward, contentDescription = null, tint = Color.White)
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))
                Text("Acciones Rápidas", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)

                MenuCardIcon(Icons.Filled.Group, "Gestionar Alumnos", "Ver, agregar y editar estudiantes") {
                    navController.navigate("gestionAlumnos")
                }
                MenuCardIcon(Icons.Filled.School, "Gestionar Profesores", "Administrar personal docente") {
                    navController.navigate("gestionProfesores")
                }
                MenuCardIcon(Icons.Filled.MenuBook, "Gestionar Cursos", "Crear y modificar cursos") {
                    navController.navigate("gestionCursos")
                }
                MenuCardIcon(Icons.Filled.BarChart, "Ver Reportes", "Estadísticas y análisis") {
                    navController.navigate("reportesScreen")
                }
                MenuCardIcon(Icons.Filled.HowToReg, "Matrículas", "Gestionar inscripciones") {
                    navController.navigate("gestionMatriculas")
                }
                MenuCardIcon(Icons.Filled.AccountCircle, "Mi Perfil", "Ajustes y cuenta de administrador") {
                    navController.navigate("perfilAdmin")
                }

                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "© 2026 Instituto Educativo. Administración.",
                    color = Color(0xB3FFFFFF),
                    fontSize = 11.sp,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}

@Composable
fun StatCard(
    icono: ImageVector,
    valor: String,
    etiqueta: String,
    color: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
        modifier = modifier.clickable { onClick() }
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .background(color.copy(alpha = 0.15f), RoundedCornerShape(10.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icono, contentDescription = null, tint = color)
            }
            Spacer(modifier = Modifier.height(10.dp))
            Text(valor, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color(0xFF222222))
            Text(etiqueta, fontSize = 12.sp, color = Color.Gray)
        }
    }
}

@Composable
fun MenuCardIcon(
    icono: ImageVector,
    titulo: String,
    descripcion: String,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
        modifier = Modifier.fillMaxWidth().clickable { onClick() }
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(18.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .background(Color(0xFF2962FF).copy(alpha = 0.12f), RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icono, contentDescription = null, tint = Color(0xFF2962FF))
            }
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(titulo, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color(0xFF222222))
                Text(descripcion, fontSize = 12.sp, color = Color.Gray)
            }
            Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = Color.Gray)
        }
    }
}
