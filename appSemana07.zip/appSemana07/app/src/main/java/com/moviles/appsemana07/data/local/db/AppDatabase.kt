package com.moviles.appsemana07.data.local.db

import androidx.room.Database
import androidx.room.RoomDatabase
import com.moviles.appsemana07.data.local.dao.UsuarioDao
import com.moviles.appsemana07.data.local.entity.UsuarioEntity

@Database(entities = [UsuarioEntity::class], version = 1)
abstract class AppDatabase : RoomDatabase() {
    abstract fun usuarioDao() : UsuarioDao
}