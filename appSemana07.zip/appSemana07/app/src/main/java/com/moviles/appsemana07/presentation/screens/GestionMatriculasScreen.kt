package com.moviles.appsemana07.presentation.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.moviles.appsemana07.domain.model.EstadoMatricula

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GestionMatriculasScreen(navController: NavController) {
    val fondoDegradado = Brush.linearGradient(colors = listOf(Color(0xFF8A2BE2), Color(0xFF4169E1)))
    var mostrarDialogo by remember { mutableStateOf(false) }

    Scaffold { paddingValues ->
        Box(modifier = Modifier.fillMaxSize().background(fondoDegradado).padding(paddingValues)) {
            Column(modifier = Modifier.fillMaxSize().padding(24.dp)) {

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Volver", tint = Color.White)
                    }
                    Text("Matrículas", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.weight(1f))
                    Button(
                        onClick = { mostrarDialogo = true },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2962FF))
                    ) {
                        Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Nuevo")
                    }
                }
                Text("Gestionar inscripciones de alumnos", color = Color(0xFFE0E0E0), fontSize = 13.sp)

                Spacer(modifier = Modifier.height(10.dp))

                Row {
                    EstadoChip("Confirmadas: ${AdminRepo.matriculas.count { it.estado == EstadoMatricula.CONFIRMADA }}", Color(0xFF00C853))
                    Spacer(modifier = Modifier.width(10.dp))
                    EstadoChip("Pendientes: ${AdminRepo.matriculas.count { it.estado == EstadoMatricula.PENDIENTE }}", Color(0xFFFFAB00))
                }

                Spacer(modifier = Modifier.height(16.dp))

                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(AdminRepo.matriculas, key = { it.id }) { matricula ->
                        Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.fillMaxWidth()) {
                            Row(modifier = Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.Person, contentDescription = null, tint = Color.Gray)
                                Spacer(modifier = Modifier.width(10.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(matricula.alumno, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                    Text(matricula.curso, fontSize = 13.sp, color = Color.Gray)
                                    Text(matricula.fecha, fontSize = 12.sp, color = Color.Gray)
                                }
                                val confirmada = matricula.estado == EstadoMatricula.CONFIRMADA
                                EstadoChip(if (confirmada) "Confirmada" else "Pendiente", if (confirmada) Color(0xFF00C853) else Color(0xFFFFAB00))
                                IconButton(onClick = { AdminRepo.cambiarEstadoMatricula(matricula) }) {
                                    Icon(Icons.Filled.Edit, contentDescription = "Cambiar estado", tint = Color(0xFF2962FF))
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (mostrarDialogo) {
        NuevaMatriculaDialog(
            onDismiss = { mostrarDialogo = false },
            onConfirmar = { alumno, curso ->
                AdminRepo.agregarMatricula(alumno, curso)
                mostrarDialogo = false
            }
        )
    }
}

@Composable
fun EstadoChip(texto: String, color: Color) {
    Box(modifier = Modifier.background(color.copy(alpha = 0.18f), RoundedCornerShape(20.dp)).padding(horizontal = 12.dp, vertical = 6.dp)) {
        Text(texto, color = color, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun NuevaMatriculaDialog(onDismiss: () -> Unit, onConfirmar: (String, String) -> Unit) {
    var alumno by remember { mutableStateOf("") }
    var curso by remember { mutableStateOf(AdminRepo.cursos.firstOrNull()?.nombre ?: "") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Nueva Matrícula", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(value = alumno, onValueChange = { alumno = it }, label = { Text("Nombre del alumno") }, modifier = Modifier.fillMaxWidth())
                ComboBoxCurso(seleccion = curso, opciones = AdminRepo.cursos.map { it.nombre }, onSeleccion = { curso = it })
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirmar(alumno, curso) },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2962FF)),
                enabled = alumno.isNotBlank()
            ) { Text("Registrar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}
