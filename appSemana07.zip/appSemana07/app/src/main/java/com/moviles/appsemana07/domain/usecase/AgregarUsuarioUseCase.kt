package com.moviles.appsemana07.domain.usecase

import com.moviles.appsemana07.domain.model.Usuario
import com.moviles.appsemana07.domain.repository.UsuarioRepository
class AgregarUsuarioUseCase(private val rep : UsuarioRepository) {
    suspend operator fun invoke(usuario: Usuario){
        if(usuario.nombre.isBlank()) throw Exception("Nombre vacío")
        if(usuario.apellido.isBlank()) throw Exception("Apellido vacío")
        if(usuario.edad <= 0) throw Exception("Edad inválida")

        rep.insertar(usuario)
    }
}