package com.moviles.appsemana07.presentation.screens

import com.moviles.appsemana07.R

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LoginScreen(navController: NavController) {

    var usuario by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val keyboardController = LocalSoftwareKeyboardController.current

    var mostrarDialogoRecuperar by remember { mutableStateOf(false) }
    var correoRecuperar by remember { mutableStateOf("") }
    var correoRecuperarEnviado by remember { mutableStateOf(false) }

    val fondoDegradado = Brush.linearGradient(
        colors = listOf(Color(0xFF8A2BE2), Color(0xFF4169E1))
    )

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { padding ->

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(fondoDegradado)
                .padding(padding),
            contentAlignment = Alignment.Center
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                // 1. Logotipo del Birrete
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = Color.White,
                    modifier = Modifier.size(60.dp)
                ) {
                    Icon(
                        painter = painterResource(id = R.drawable.birrete_icon),
                        contentDescription = "Logo Instituto",
                        modifier = Modifier.padding(12.dp),
                        tint = Color(0xFF2962FF)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "Instituto Educativo",
                    color = Color.White,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold
                )

                Text(
                    text = "Plataforma Académica Digital",
                    color = Color(0xFFE0E0E0),
                    fontSize = 14.sp
                )

                Spacer(modifier = Modifier.height(32.dp))

                Card(
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "Iniciar Sesión",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF333333)
                        )

                        Spacer(modifier = Modifier.height(24.dp))

                        Column(modifier = Modifier.fillMaxWidth()) {
                            Text(
                                text = "Correo Institucional (Usuario)",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.Gray
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            OutlinedTextField(
                                value = usuario,
                                onValueChange = { usuario = it },
                                placeholder = { Text("correo@instituto.edu") },
                                leadingIcon = {
                                    Icon(
                                        painter = painterResource(id = R.drawable.mail_icon),
                                        contentDescription = "Icono Correo",
                                        tint = Color.Gray,
                                        modifier = Modifier.size(20.dp)
                                    )
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .onFocusChanged { estado ->
                                       if (estado.isFocused) keyboardController?.show()
                                    },
                                singleLine = true,
                                shape = RoundedCornerShape(12.dp),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email)
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Column(modifier = Modifier.fillMaxWidth()) {
                            Text(
                                text = "Contraseña",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.Gray
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            OutlinedTextField(
                                value = password,
                                onValueChange = { password = it },
                                placeholder = { Text("••••••••") },
                                leadingIcon = {
                                    Icon(
                                        painter = painterResource(id = R.drawable.lock_icon),
                                        contentDescription = "Icono Contraseña",
                                        tint = Color.Gray,
                                        modifier = Modifier.size(20.dp)
                                    )
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .onFocusChanged { estado ->
                                        if (estado.isFocused) keyboardController?.show()
                                    },
                                singleLine = true,
                                visualTransformation = PasswordVisualTransformation(),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                                shape = RoundedCornerShape(12.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "¿Olvidaste tu contraseña?",
                            color = Color(0xFF1976D2),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier
                                .align(Alignment.Start)
                                .clickable {
                                    correoRecuperar = usuario
                                    correoRecuperarEnviado = false
                                    mostrarDialogoRecuperar = true
                                }
                        )

                        Spacer(modifier = Modifier.height(24.dp))

                        Button(
                            onClick = {
                                when (usuario) {
                                    "admin" -> if (password == "admin123") {
                                        navController.navigate("adminMenu") {
                                            popUpTo("login") { inclusive = true }
                                        }
                                    }
                                    "profesor" -> if (password == "profesor123") {
                                        navController.navigate("profesor") {
                                            popUpTo("login") { inclusive = true }
                                        }
                                    }
                                    "alumno" -> if (password == "alumno123") {
                                        navController.navigate("alumno") {
                                            popUpTo("login") { inclusive = true }
                                        }
                                    }
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2962FF))
                        ) {
                            Text("Ingresar", fontSize = 16.sp, color = Color.White)
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Text(
                            text = "Acceso exclusivo para estudiantes y profesores",
                            color = Color.Gray,
                            fontSize = 11.sp,
                            textAlign = TextAlign.Center
                        )
                    }
                }

                Spacer(modifier = Modifier.height(40.dp))
            }

            Text(
                text = "© 2026 Instituto Educativo. Todos los derechos reservados.",
                color = Color(0xB3FFFFFF),
                fontSize = 10.sp,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 24.dp)
            )

            if (mostrarDialogoRecuperar) {
                AlertDialog(
                    onDismissRequest = { mostrarDialogoRecuperar = false },
                    title = { Text("Recuperar contraseña", fontWeight = FontWeight.Bold) },
                    text = {
                        Column {
                            if (!correoRecuperarEnviado) {
                                Text(
                                    "Ingresa tu correo institucional y te enviaremos instrucciones para restablecer tu contraseña.",
                                    fontSize = 13.sp,
                                    color = Color.Gray
                                )
                                Spacer(modifier = Modifier.height(12.dp))
                                OutlinedTextField(
                                    value = correoRecuperar,
                                    onValueChange = { correoRecuperar = it },
                                    placeholder = { Text("correo@instituto.edu") },
                                    singleLine = true,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .onFocusChanged { estado ->
                                            if (estado.isFocused) keyboardController?.show()
                                        },
                                    shape = RoundedCornerShape(12.dp),
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email)
                                )
                            } else {
                                Text(
                                    "Si el correo \"$correoRecuperar\" está registrado, recibirás un enlace para restablecer tu contraseña en unos minutos.",
                                    fontSize = 13.sp,
                                    color = Color(0xFF333333)
                                )
                            }
                        }
                    },
                    confirmButton = {
                        if (!correoRecuperarEnviado) {
                            TextButton(
                                enabled = correoRecuperar.isNotBlank(),
                                onClick = {
                                    correoRecuperarEnviado = true
                                    scope.launch {
                                        snackbarHostState.showSnackbar("Instrucciones enviadas a $correoRecuperar")
                                    }
                                }
                            ) { Text("Enviar") }
                        } else {
                            TextButton(onClick = { mostrarDialogoRecuperar = false }) { Text("Aceptar") }
                        }
                    },
                    dismissButton = {
                        if (!correoRecuperarEnviado) {
                            TextButton(onClick = { mostrarDialogoRecuperar = false }) { Text("Cancelar") }
                        }
                    }
                )
            }
        }
    }
}