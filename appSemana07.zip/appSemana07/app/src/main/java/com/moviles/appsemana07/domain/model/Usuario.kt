package com.moviles.appsemana07.domain.model

data class Usuario(
    val id: Int = 0,
    val nombre: String,
    val apellido: String,
    val edad: Int
)
