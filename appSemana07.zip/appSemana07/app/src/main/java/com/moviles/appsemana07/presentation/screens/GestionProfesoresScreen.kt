package com.moviles.appsemana07.presentation.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.moviles.appsemana07.domain.model.Profesor

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GestionProfesoresScreen(navController: NavController) {
    val fondoDegradado = Brush.linearGradient(colors = listOf(Color(0xFF8A2BE2), Color(0xFF4169E1)))

    var cursoFiltro by remember { mutableStateOf("Todos") }
    var mostrarDialogo by remember { mutableStateOf(false) }
    var profesorEditar by remember { mutableStateOf<Profesor?>(null) }

    val opcionesCurso = listOf("Todos") + AdminRepo.cursos.map { it.nombre }
    val profesoresFiltrados = AdminRepo.profesores.filter { cursoFiltro == "Todos" || it.especialidad == cursoFiltro }

    Scaffold { paddingValues ->
        Box(modifier = Modifier.fillMaxSize().background(fondoDegradado).padding(paddingValues)) {
            Column(modifier = Modifier.fillMaxSize().padding(24.dp)) {

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Volver", tint = Color.White)
                    }
                    Text("Gestión de Profesores", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.weight(1f))
                    Button(
                        onClick = { mostrarDialogo = true },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2962FF))
                    ) {
                        Icon(Icons.Filled.PersonAdd, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Agregar")
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                ComboBoxCurso(seleccion = cursoFiltro, opciones = opcionesCurso, onSeleccion = { cursoFiltro = it })

                Spacer(modifier = Modifier.height(16.dp))

                LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(profesoresFiltrados, key = { it.id }) { profesor ->
                        val cantidadAlumnos = AdminRepo.alumnosPorCurso(profesor.especialidad).size
                        Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.fillMaxWidth()) {
                            Column(modifier = Modifier.padding(20.dp)) {
                                Text(profesor.nombre, fontWeight = FontWeight.Bold, color = Color(0xFF2962FF), fontSize = 16.sp)
                                Spacer(modifier = Modifier.height(4.dp))
                                CursoChip(profesor.especialidad)
                                Spacer(modifier = Modifier.height(8.dp))
                                InfoLinea(Icons.Filled.Email, profesor.correo)
                                InfoLinea(Icons.Filled.Phone, profesor.telefono)
                                InfoLinea(Icons.Filled.Schedule, profesor.horario)
                                InfoLinea(Icons.Filled.Group, "$cantidadAlumnos alumnos en este curso")
                                Row(modifier = Modifier.padding(top = 10.dp)) {
                                    Button(
                                        onClick = { profesorEditar = profesor },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2962FF))
                                    ) {
                                        Icon(Icons.Filled.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Editar")
                                    }
                                    Spacer(Modifier.width(8.dp))
                                    Button(
                                        onClick = { AdminRepo.eliminarProfesor(profesor) },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD32F2F))
                                    ) {
                                        Icon(Icons.Filled.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Eliminar")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (mostrarDialogo) {
        ProfesorDialog(
            titulo = "Agregar Profesor",
            especialidades = AdminRepo.cursos.map { it.nombre },
            onDismiss = { mostrarDialogo = false },
            onConfirmar = { nombre, especialidad, horario ->
                AdminRepo.agregarProfesor(nombre, especialidad, horario)
                mostrarDialogo = false
            }
        )
    }

    profesorEditar?.let { profesor ->
        ProfesorDialog(
            titulo = "Editar Profesor",
            especialidades = AdminRepo.cursos.map { it.nombre },
            nombreInicial = profesor.nombre,
            especialidadInicial = profesor.especialidad,
            horarioInicial = profesor.horario,
            onDismiss = { profesorEditar = null },
            onConfirmar = { nombre, especialidad, horario ->
                AdminRepo.actualizarProfesor(profesor, nombre, especialidad, horario)
                profesorEditar = null
            }
        )
    }
}

@Composable
private fun InfoLinea(icono: androidx.compose.ui.graphics.vector.ImageVector, texto: String) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 2.dp)) {
        Icon(icono, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text(texto, fontSize = 13.sp, color = Color(0xFF444444))
    }
}

@Composable
private fun ProfesorDialog(
    titulo: String,
    especialidades: List<String>,
    nombreInicial: String = "",
    especialidadInicial: String = "",
    horarioInicial: String = "Por definir",
    onDismiss: () -> Unit,
    onConfirmar: (String, String, String) -> Unit
) {
    var nombre by remember { mutableStateOf(nombreInicial) }
    var especialidad by remember { mutableStateOf(especialidadInicial.ifBlank { especialidades.firstOrNull() ?: "" }) }
    var horario by remember { mutableStateOf(horarioInicial) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(titulo, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(value = nombre, onValueChange = { nombre = it }, label = { Text("Nombre del profesor") }, modifier = Modifier.fillMaxWidth())
                ComboBoxCurso(seleccion = especialidad, opciones = especialidades, onSeleccion = { especialidad = it }, etiqueta = "Especialidad")
                OutlinedTextField(value = horario, onValueChange = { horario = it }, label = { Text("Horario") }, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirmar(nombre, especialidad, horario) },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2962FF)),
                enabled = nombre.isNotBlank()
            ) { Text("Guardar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}
