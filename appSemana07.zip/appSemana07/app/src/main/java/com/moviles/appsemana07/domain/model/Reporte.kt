package com.moviles.appsemana07.domain.model

data class Reporte(
    val titulo: String,
    val detalle: String,
    val fecha: String
)
