package com.moviles.appsemana07.presentation.screens

data class CursoAlumno(
    val id: Int,
    val nombre: String,
    val profesor: String,
    val horarioTexto: String,
    val creditos: Int,
    val notaGeneral: Double,   // Nota final del curso (no de un examen puntual)
    val progreso: Int,
    val examen1: Int,
    val examen2: Int,
    val terceraEvaluacionNombre: String, // "Proyecto" o "Laboratorio"
    val terceraEvaluacionValor: Int
)

enum class EstadoAsistencia(val etiqueta: String) {
    A_TIEMPO("A tiempo"),
    TARDE("Tarde"),
    FALTA("Falta")
}

data class RegistroAsistencia(
    val fecha: String,
    val curso: String,
    val estado: EstadoAsistencia
)

data class ClaseHorario(
    val dia: String,
    val curso: String,
    val horaInicio: String,
    val horaFin: String,
    val aula: String
)

data class AvisoAlumno(
    val titulo: String,
    val mensaje: String,
    val curso: String,
    val profesor: String,
    val fecha: String,
    val esNuevo: Boolean = false
)

object AlumnoRepo {

    val cursos = listOf(
        CursoAlumno(
            id = 1,
            nombre = "Desarrollo Web Full Stack",
            profesor = "Prof. María García",
            horarioTexto = "Lun-Mié 18:00-20:00",
            creditos = 6,
            notaGeneral = 18.0,
            progreso = 75,
            examen1 = 18, examen2 = 17,
            terceraEvaluacionNombre = "Proyecto", terceraEvaluacionValor = 19
        ),
        CursoAlumno(
            id = 2,
            nombre = "Diseño Gráfico Profesional",
            profesor = "Prof. Pedro Rodríguez",
            horarioTexto = "Mar-Jue 20:00-22:00",
            creditos = 4,
            notaGeneral = 17.2,
            progreso = 60,
            examen1 = 16, examen2 = 17,
            terceraEvaluacionNombre = "Proyecto", terceraEvaluacionValor = 18
        ),
        CursoAlumno(
            id = 3,
            nombre = "Redes y Sistemas",
            profesor = "Prof. María García",
            horarioTexto = "Lun-Vie 17:00-18:30",
            creditos = 5,
            notaGeneral = 16.2,
            progreso = 50,
            examen1 = 15, examen2 = 16,
            terceraEvaluacionNombre = "Laboratorio", terceraEvaluacionValor = 17
        ),
        CursoAlumno(
            id = 4,
            nombre = "Marketing Digital",
            profesor = "Prof. María García",
            horarioTexto = "Sáb 09:00-13:00",
            creditos = 3,
            notaGeneral = 19.3,
            progreso = 45,
            examen1 = 19, examen2 = 20,
            terceraEvaluacionNombre = "Proyecto", terceraEvaluacionValor = 19
        ),
        CursoAlumno(
            id = 5,
            nombre = "Contabilidad Empresarial",
            profesor = "Prof. Laura Díaz",
            horarioTexto = "Mar-Jue 18:00-20:00",
            creditos = 4,
            notaGeneral = 17.1,
            progreso = 40,
            examen1 = 16, examen2 = 17,
            terceraEvaluacionNombre = "Proyecto", terceraEvaluacionValor = 18
        )
    )

    val promedioGeneral: Double
        get() = cursos.map { it.notaGeneral }.average()

    val avisos = listOf(
        AvisoAlumno(
            titulo = "Material de estudio disponible",
            mensaje = "Se subió el material de la última clase a la plataforma. Revisar antes de la próxima sesión.",
            curso = "Desarrollo Web Full Stack",
            profesor = "Prof. María García",
            fecha = "12/5/2026",
            esNuevo = true
        ),
        AvisoAlumno(
            titulo = "Próximo examen programado",
            mensaje = "El examen parcial será el viernes 17 de mayo. Estudiar capítulos 1-5 del material.",
            curso = "Redes y Sistemas",
            profesor = "Prof. María García",
            fecha = "11/5/2026",
            esNuevo = true
        ),
        AvisoAlumno(
            titulo = "Clase de recuperación",
            mensaje = "Se programó una clase adicional para el sábado 18 de mayo a las 10:00 AM.",
            curso = "Diseño Gráfico Profesional",
            profesor = "Prof. Pedro Rodríguez",
            fecha = "9/5/2026",
            esNuevo = false
        )
    )

    val diaActual = "Lunes"

    val horario = listOf(
        ClaseHorario("Lunes", "Redes y Sistemas", "17:00", "18:30", "Lab 401"),
        ClaseHorario("Lunes", "Desarrollo Web Full Stack", "18:00", "20:00", "Lab 301"),
        ClaseHorario("Martes", "Contabilidad Empresarial", "18:00", "20:00", "Aula 102"),
        ClaseHorario("Martes", "Diseño Gráfico Profesional", "20:00", "22:00", "Aula 205"),
        ClaseHorario("Miércoles", "Redes y Sistemas", "17:00", "18:30", "Lab 401"),
        ClaseHorario("Miércoles", "Desarrollo Web Full Stack", "18:00", "20:00", "Lab 301"),
        ClaseHorario("Jueves", "Contabilidad Empresarial", "18:00", "20:00", "Aula 102"),
        ClaseHorario("Jueves", "Diseño Gráfico Profesional", "20:00", "22:00", "Aula 205"),
        ClaseHorario("Viernes", "Redes y Sistemas", "17:00", "18:30", "Lab 401"),
        ClaseHorario("Sábado", "Marketing Digital", "09:00", "13:00", "Aula 110")
    )

    val clasesDeHoy: List<ClaseHorario>
        get() = horario.filter { it.dia == diaActual }

    val asistencia = listOf(
        RegistroAsistencia("05/05/2026", "Desarrollo Web Full Stack", EstadoAsistencia.A_TIEMPO),
        RegistroAsistencia("06/05/2026", "Redes y Sistemas", EstadoAsistencia.TARDE),
        RegistroAsistencia("07/05/2026", "Marketing Digital", EstadoAsistencia.A_TIEMPO),
        RegistroAsistencia("08/05/2026", "Diseño Gráfico Profesional", EstadoAsistencia.A_TIEMPO),
        RegistroAsistencia("11/05/2026", "Redes y Sistemas", EstadoAsistencia.A_TIEMPO),
        RegistroAsistencia("12/05/2026", "Desarrollo Web Full Stack", EstadoAsistencia.FALTA),
        RegistroAsistencia("13/05/2026", "Contabilidad Empresarial", EstadoAsistencia.A_TIEMPO),
        RegistroAsistencia("14/05/2026", "Marketing Digital", EstadoAsistencia.A_TIEMPO),
        RegistroAsistencia("15/05/2026", "Redes y Sistemas", EstadoAsistencia.A_TIEMPO),
        RegistroAsistencia("18/05/2026", "Diseño Gráfico Profesional", EstadoAsistencia.A_TIEMPO),
        RegistroAsistencia("19/05/2026", "Desarrollo Web Full Stack", EstadoAsistencia.A_TIEMPO),
        RegistroAsistencia("20/05/2026", "Contabilidad Empresarial", EstadoAsistencia.A_TIEMPO),
        RegistroAsistencia("21/05/2026", "Redes y Sistemas", EstadoAsistencia.A_TIEMPO),
        RegistroAsistencia("22/05/2026", "Marketing Digital", EstadoAsistencia.A_TIEMPO),
        RegistroAsistencia("25/05/2026", "Desarrollo Web Full Stack", EstadoAsistencia.A_TIEMPO),
        RegistroAsistencia("26/05/2026", "Diseño Gráfico Profesional", EstadoAsistencia.A_TIEMPO),
        RegistroAsistencia("27/05/2026", "Redes y Sistemas", EstadoAsistencia.A_TIEMPO),
        RegistroAsistencia("28/05/2026", "Contabilidad Empresarial", EstadoAsistencia.A_TIEMPO),
        RegistroAsistencia("29/05/2026", "Marketing Digital", EstadoAsistencia.A_TIEMPO),
        RegistroAsistencia("01/06/2026", "Desarrollo Web Full Stack", EstadoAsistencia.A_TIEMPO)
    )
    val porcentajeAsistencia: Int
        get() {
            val asistio = asistencia.count { it.estado != EstadoAsistencia.FALTA }
            return ((asistio.toDouble() / asistencia.size) * 100).toInt()
        }
}
