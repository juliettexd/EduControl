package com.moviles.appsemana07.presentation.screens

import androidx.compose.runtime.mutableStateListOf
import com.moviles.appsemana07.domain.model.Alumno
import com.moviles.appsemana07.domain.model.Curso
import com.moviles.appsemana07.domain.model.EstadoMatricula
import com.moviles.appsemana07.domain.model.Matricula
import com.moviles.appsemana07.domain.model.Profesor
import com.moviles.appsemana07.domain.model.Reporte
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object AdminRepo {

    val cursos = mutableStateListOf(
        Curso("Desarrollo Web Full Stack", "6 meses", "Lun-Mié 18:00-20:00", "María García"),
        Curso("Diseño Gráfico Profesional", "4 meses", "Mar-Jue 19:00-21:00", "Pedro Rodríguez"),
        Curso("Redes y Sistemas", "5 meses", "Lun-Vie 17:00-18:30", "María García"),
        Curso("Marketing Digital", "3 meses", "Sáb 09:00-13:00", "María García"),
        Curso("Contabilidad Empresarial", "6 meses", "Mar-Jue 18:00-20:00", "Laura Díaz")
    )

    val profesores = mutableStateListOf(
        Profesor(1, "María García", "maria@instituto.edu", "999-111-222", "Desarrollo Web Full Stack", "Lun-Mié 18:00-20:00", 92),
        Profesor(2, "Pedro Rodríguez", "pedro@instituto.edu", "999-222-333", "Diseño Gráfico Profesional", "Mar-Jue 19:00-21:00", 88),
        Profesor(3, "María García", "maria@instituto.edu", "999-111-222", "Redes y Sistemas", "Lun-Vie 17:00-18:30", 90),
        Profesor(4, "María García", "maria@instituto.edu", "999-111-222", "Marketing Digital", "Sáb 09:00-13:00", 91),
        Profesor(5, "Laura Díaz", "laura@instituto.edu", "999-555-666", "Contabilidad Empresarial", "Mar-Jue 18:00-20:00", 85)
    )

    val alumnos = mutableStateListOf(
        Alumno(1, "Juan Pérez", "juan@email.com", "Desarrollo Web Full Stack", "Activo"),
        Alumno(2, "María García", "maria@email.com", "Diseño Gráfico Profesional", "Activo"),
        Alumno(3, "Carlos López", "carlos@email.com", "Redes y Sistemas", "Activo"),
        Alumno(4, "Ana Martínez", "ana@email.com", "Desarrollo Web Full Stack", "Inactivo"),
        Alumno(5, "Luis Torres", "luis@email.com", "Marketing Digital", "Activo")
    )

    val matriculas = mutableStateListOf(
        Matricula(1, "Rosa Fernández", "Desarrollo Web Full Stack", "14/01/2026", EstadoMatricula.CONFIRMADA),
        Matricula(2, "Diego Ramos", "Diseño Gráfico Profesional", "19/02/2026", EstadoMatricula.CONFIRMADA),
        Matricula(3, "Elena Vidal", "Redes y Sistemas", "09/03/2026", EstadoMatricula.PENDIENTE),
        Matricula(4, "Jorge Salas", "Marketing Digital", "04/04/2026", EstadoMatricula.CONFIRMADA),
        Matricula(5, "Paola Ríos", "Contabilidad Empresarial", "11/05/2026", EstadoMatricula.PENDIENTE)
    )

    val reportes = mutableStateListOf<Reporte>()

    private var nextAlumnoId = 100
    private var nextProfesorId = 100
    private var nextMatriculaId = 100

    private fun fechaHoy(): String =
        SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date())

    private fun registrarReporte(titulo: String, detalle: String) {
        reportes.add(0, Reporte(titulo, detalle, fechaHoy()))
    }

    fun alumnosPorCurso(curso: String) = alumnos.filter { it.curso == curso }

    fun profesoresPorCurso(curso: String) = profesores.filter { it.especialidad == curso }

    fun agregarAlumno(nombre: String, correo: String, curso: String) {
        alumnos.add(Alumno(nextAlumnoId++, nombre, correo, curso, "Activo"))
        registrarReporte("Nuevo alumno", "$nombre se matriculó en $curso")
    }

    fun actualizarAlumno(original: Alumno, curso: String, estado: String) {
        val idx = alumnos.indexOf(original)
        if (idx >= 0) alumnos[idx] = original.copy(curso = curso, estado = estado)
        registrarReporte("Alumno actualizado", "${original.nombre} ahora en $curso ($estado)")
    }

    fun eliminarAlumno(alumno: Alumno) {
        alumnos.remove(alumno)
        registrarReporte("Alumno eliminado", "${alumno.nombre} fue retirado de ${alumno.curso}")
    }

    fun agregarProfesor(nombre: String, especialidad: String, horario: String) {
        profesores.add(Profesor(nextProfesorId++, nombre, "$nombre@instituto.edu", "999-000-000", especialidad, horario))
        registrarReporte("Nuevo profesor", "$nombre se incorporó dictando $especialidad")
    }

    fun actualizarProfesor(original: Profesor, nombre: String, especialidad: String, horario: String) {
        val idx = profesores.indexOf(original)
        if (idx >= 0) profesores[idx] = original.copy(nombre = nombre, especialidad = especialidad, horario = horario)
        registrarReporte("Profesor actualizado", "$nombre ahora dicta $especialidad")
    }

    fun eliminarProfesor(profesor: Profesor) {
        profesores.remove(profesor)
        registrarReporte("Profesor retirado", "${profesor.nombre} ya no dicta ${profesor.especialidad}")
    }

    fun agregarCurso(nombre: String, duracion: String, horario: String) {
        cursos.add(Curso(nombre, duracion, horario))
        registrarReporte("Nuevo curso", "Se aperturó el curso $nombre")
    }

    fun editarCurso(original: Curso, nuevoNombre: String, profesor: String) {
        val idx = cursos.indexOf(original)
        if (idx >= 0) cursos[idx] = original.copy(nombre = nuevoNombre, profesor = profesor)
        registrarReporte("Curso actualizado", "$nuevoNombre ahora a cargo de $profesor")
    }

    fun agregarMatricula(alumno: String, curso: String) {
        matriculas.add(0, Matricula(nextMatriculaId++, alumno, curso, fechaHoy().substringBefore(" "), EstadoMatricula.PENDIENTE))
        registrarReporte("Nueva matrícula", "$alumno solicitó inscripción en $curso")
    }

    fun cambiarEstadoMatricula(matricula: Matricula) {
        val idx = matriculas.indexOf(matricula)
        if (idx < 0) return
        val nuevoEstado = if (matricula.estado == EstadoMatricula.PENDIENTE) EstadoMatricula.CONFIRMADA else EstadoMatricula.PENDIENTE
        matriculas[idx] = matricula.copy(estado = nuevoEstado)

        if (nuevoEstado == EstadoMatricula.CONFIRMADA) {
            if (alumnos.none { it.nombre == matricula.alumno && it.curso == matricula.curso }) {
                alumnos.add(Alumno(nextAlumnoId++, matricula.alumno, "-", matricula.curso, "Activo"))
            }
            registrarReporte("Matrícula confirmada", "${matricula.alumno} confirmado en ${matricula.curso}")
        } else {
            registrarReporte("Matrícula pendiente", "${matricula.alumno} pasó a pendiente")
        }
    }
    fun asistenciaPromedio(): Int {
        val cursosConRegistro = ProfesorRepo.cursos.filter { it.asistenciaTomadaHoy.value }
        if (cursosConRegistro.isNotEmpty()) {
            return cursosConRegistro.map { it.porcentajeAsistencia.value }.average().toInt()
        }
        return if (profesores.isEmpty()) 0 else profesores.map { it.asistencia }.average().toInt()
    }

    fun porcentajeMatriculasConfirmadas(): Int {
        if (matriculas.isEmpty()) return 0
        val confirmadas = matriculas.count { it.estado == EstadoMatricula.CONFIRMADA }
        return (confirmadas * 100) / matriculas.size
    }

    fun cursosAperturadosUltimoPeriodo(): Pair<Int, Int> {
        val conAlumnos = cursos.count { alumnosPorCurso(it.nombre).isNotEmpty() }
        val porcentaje = if (cursos.isNotEmpty()) (conAlumnos * 100) / cursos.size else 0
        return conAlumnos to porcentaje
    }

    fun permanenciaAlumnos(): Int {
        if (alumnos.isEmpty()) return 0
        val activos = alumnos.count { it.estado == "Activo" }
        return (activos * 100) / alumnos.size
    }
}
