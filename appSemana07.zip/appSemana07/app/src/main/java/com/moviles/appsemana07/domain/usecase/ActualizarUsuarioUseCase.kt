package com.moviles.appsemana07.domain.usecase

import com.moviles.appsemana07.domain.model.Usuario
import com.moviles.appsemana07.domain.repository.UsuarioRepository

class ActualizarUsuarioUseCase(private val repo : UsuarioRepository) {
    suspend operator fun invoke(usuario: Usuario){
        if (usuario.id <= 0) throw Exception("ID inválido")
        if (usuario.nombre.isBlank()) throw Exception("Nombre vacio")
        if (usuario.apellido.isBlank()) throw Exception("Apellidos vacio")
        if (usuario.edad <= 0) throw Exception("Edad inválida")

        repo.actualizar(usuario)
    }
}