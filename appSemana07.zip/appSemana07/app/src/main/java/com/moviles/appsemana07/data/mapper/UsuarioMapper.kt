package com.moviles.appsemana07.data.mapper

import com.moviles.appsemana07.data.local.entity.UsuarioEntity
import com.moviles.appsemana07.domain.model.Usuario

object UsuarioMapper {
    fun toDomain(entidad : UsuarioEntity) : Usuario =
        Usuario(entidad.id,entidad.nombre,entidad.apellido,entidad.edad)

    fun toEntity(usuario: Usuario) : UsuarioEntity =
        UsuarioEntity(usuario.id,usuario.nombre,usuario.apellido,usuario.edad)
}