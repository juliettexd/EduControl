package com.moviles.appsemana07.presentation.screens

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
class AlumnoDeCurso(
    val id: Int,
    val nombre: String,
    examen1Inicial: Int,
    examen2Inicial: Int,
    examen3Inicial: Int,
    asistioInicial: Boolean = true
) {
    var examen1 by mutableStateOf(examen1Inicial)
    var examen2 by mutableStateOf(examen2Inicial)
    var examen3 by mutableStateOf(examen3Inicial)
    var asistio by mutableStateOf(asistioInicial)

    val promedio: Double
        get() = (examen1 + examen2 + examen3) / 3.0
}

data class CursoProfesor(
    val id: Int,
    val nombre: String,
    val horarioTexto: String,
    val aula: String,
    val duracion: String,
    val proximoTema: String,
    val totalAlumnos: Int,
    val progreso: Int,
    val alumnos: androidx.compose.runtime.snapshots.SnapshotStateList<AlumnoDeCurso>,
    var porcentajeAsistencia: androidx.compose.runtime.MutableState<Int> = mutableStateOf(90),
    var notasGuardadas: androidx.compose.runtime.MutableState<Boolean> = mutableStateOf(false),
    var asistenciaTomadaHoy: androidx.compose.runtime.MutableState<Boolean> = mutableStateOf(false)
)

data class AvisoProfesor(
    val id: Int,
    var titulo: String,
    var mensaje: String,
    var curso: String,
    val fecha: String,
    var vistas: Int
)

data class MensajeAlumno(
    val curso: String,
    val alumno: String,
    val mensaje: String,
    val hora: String
)

object ProfesorRepo {

    val nombreProfesor = "María García"

    val cursos = listOf(
        CursoProfesor(
            id = 1,
            nombre = "Desarrollo Web Full Stack",
            horarioTexto = "Lun-Mié 18:00-20:00",
            aula = "Lab 301",
            duracion = "6 meses",
            proximoTema = "Próximo tema: APIs REST con Node.js",
            totalAlumnos = 32,
            progreso = 75,
            alumnos = mutableStateListOf(
                AlumnoDeCurso(1, "Juan Pérez", 18, 16, 17),
                AlumnoDeCurso(2, "María García", 19, 20, 19),
                AlumnoDeCurso(3, "Carlos López", 14, 15, 16, asistioInicial = false),
                AlumnoDeCurso(4, "Ana Martínez", 17, 18, 17)
            ),
            porcentajeAsistencia = mutableStateOf(95)
        ),
        CursoProfesor(
            id = 2,
            nombre = "Redes y Sistemas",
            horarioTexto = "Lun-Vie 17:00-18:30",
            aula = "Lab 401",
            duracion = "5 meses",
            proximoTema = "Próximo tema: Configuración de subredes",
            totalAlumnos = 25,
            progreso = 50,
            alumnos = mutableStateListOf(
                AlumnoDeCurso(5, "Juan Pérez", 16, 17, 18),
                AlumnoDeCurso(6, "María García", 18, 19, 20),
                AlumnoDeCurso(7, "Carlos López", 15, 14, 16),
                AlumnoDeCurso(8, "Ana Martínez", 17, 17, 18)
            ),
            porcentajeAsistencia = mutableStateOf(90)
        ),
        CursoProfesor(
            id = 3,
            nombre = "Marketing Digital",
            horarioTexto = "Sáb 09:00-13:00",
            aula = "Aula 110",
            duracion = "3 meses",
            proximoTema = "Próximo tema: Campañas en redes sociales",
            totalAlumnos = 35,
            progreso = 45,
            alumnos = mutableStateListOf(
                AlumnoDeCurso(9, "Juan Pérez", 18, 16, 17),
                AlumnoDeCurso(10, "María García", 19, 20, 19),
                AlumnoDeCurso(11, "Carlos López", 14, 15, 16),
                AlumnoDeCurso(12, "Ana Martínez", 17, 18, 17)
            ),
            porcentajeAsistencia = mutableStateOf(91)
        )
    )

    fun cursoPorId(id: Int): CursoProfesor? = cursos.find { it.id == id }

    val totalAlumnos: Int
        get() = cursos.sumOf { it.totalAlumnos }

    val porcentajeAsistenciaHoy: Int
        get() = (cursos.sumOf { it.porcentajeAsistencia.value } / cursos.size)

    val avisos = mutableStateListOf(
        AvisoProfesor(
            id = 1,
            titulo = "Clase de recuperación",
            mensaje = "Se programó una clase adicional para el próximo sábado a las 10:00 AM.",
            curso = "Desarrollo Web Full Stack",
            fecha = "8/5/2026",
            vistas = 26
        ),
        AvisoProfesor(
            id = 2,
            titulo = "Material de estudio disponible",
            mensaje = "Se ha subido el material de la última clase a la plataforma.",
            curso = "Redes y Sistemas",
            fecha = "11/5/2026",
            vistas = 23
        ),
        AvisoProfesor(
            id = 3,
            titulo = "Próximo examen",
            mensaje = "El examen parcial será el viernes 17 de mayo. Estudiar capítulos 1-5.",
            curso = "Marketing Digital",
            fecha = "12/5/2026",
            vistas = 20
        )
    )

    val mensajes = listOf(
        MensajeAlumno("Desarrollo Web Full Stack", "Juan Pérez", "¿Podría revisar mi entrega del proyecto final?", "10:32 AM"),
        MensajeAlumno("Desarrollo Web Full Stack", "María García", "No pude conectarme a la clase de ayer, ¿hay grabación?", "09:10 AM"),
        MensajeAlumno("Desarrollo Web Full Stack", "Carlos López", "Tengo una duda sobre el examen 2.", "Ayer"),
        MensajeAlumno("Desarrollo Web Full Stack", "Ana Martínez", "Gracias por la retroalimentación profesora.", "Ayer"),
        MensajeAlumno("Redes y Sistemas", "Juan Pérez", "¿El proyecto se entrega en equipo o individual?", "11:45 AM"),
        MensajeAlumno("Redes y Sistemas", "María García", "¿Puede aclarar el tema de subnetting?", "10:20 AM"),
        MensajeAlumno("Redes y Sistemas", "Carlos López", "Justificación de inasistencia adjunta.", "Ayer"),
        MensajeAlumno("Redes y Sistemas", "Ana Martínez", "¿Habrá clase de recuperación esta semana?", "Ayer"),
        MensajeAlumno("Marketing Digital", "Juan Pérez", "El plan de campaña ya está listo.", "12:05 PM"),
        MensajeAlumno("Marketing Digital", "María García", "¿Podemos usar redes propias para el examen?", "09:50 AM"),
        MensajeAlumno("Marketing Digital", "Carlos López", "No entendí el último ejercicio de clase.", "Ayer"),
        MensajeAlumno("Marketing Digital", "Ana Martínez", "Consulta sobre la fecha del examen parcial.", "Ayer")
    )
}
