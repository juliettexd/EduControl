package com.moviles.appsemana07.presentation.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportesAdminScreen(navController: NavController) {
    val fondoDegradado = Brush.linearGradient(colors = listOf(Color(0xFF8A2BE2), Color(0xFF4169E1)))

    val cursosAperturados = AdminRepo.cursosAperturadosUltimoPeriodo()

    Scaffold(
        bottomBar = { BottomNavAdmin(navController = navController, rutaActual = "reportesScreen") }
    ) { paddingValues ->
        Box(modifier = Modifier.fillMaxSize().background(fondoDegradado).padding(paddingValues)) {
            Column(modifier = Modifier.fillMaxSize().padding(24.dp)) {

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Volver", tint = Color.White)
                    }
                    Text("Reportes y Estadísticas", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                    ReporteCard(
                        Icons.Filled.HowToReg, "${AdminRepo.porcentajeMatriculasConfirmadas()}%",
                        "Matrículas último periodo", Color(0xFF00C853), Modifier.weight(1f)
                    )
                    ReporteCard(
                        Icons.Filled.MenuBook, "${cursosAperturados.second}%",
                        "Cursos aperturados (${cursosAperturados.first})", Color(0xFF2962FF), Modifier.weight(1f)
                    )
                }
                Spacer(modifier = Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                    ReporteCard(
                        Icons.Filled.Schedule, "${AdminRepo.asistenciaPromedio()}%",
                        "Asistencia promedio", Color(0xFFAA00FF), Modifier.weight(1f)
                    )
                    ReporteCard(
                        Icons.Filled.TrendingUp, "${AdminRepo.permanenciaAlumnos()}%",
                        "Permanencia de alumnos", Color(0xFFFF6D00), Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))
                Text("Historial de Reportes", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Text("Se genera un reporte automático por cada cambio", color = Color(0xFFE0E0E0), fontSize = 12.sp)
                Spacer(modifier = Modifier.height(10.dp))

                if (AdminRepo.reportes.isEmpty()) {
                    Card(shape = RoundedCornerShape(14.dp), colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.fillMaxWidth()) {
                        Text(
                            "Aún no hay reportes. Se generarán automáticamente con cada matrícula, curso o profesor nuevo.",
                            modifier = Modifier.padding(16.dp), fontSize = 13.sp, color = Color.Gray
                        )
                    }
                } else {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(AdminRepo.reportes) { reporte ->
                            Card(shape = RoundedCornerShape(14.dp), colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.fillMaxWidth()) {
                                Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Filled.Description, contentDescription = null, tint = Color(0xFF2962FF), modifier = Modifier.size(20.dp))
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(reporte.titulo, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        Text(reporte.detalle, fontSize = 12.sp, color = Color.Gray)
                                    }
                                    Text(reporte.fecha, fontSize = 11.sp, color = Color.Gray)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ReporteCard(icono: ImageVector, valor: String, etiqueta: String, color: Color, modifier: Modifier = Modifier) {
    Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color.White), modifier = modifier) {
        Column(modifier = Modifier.padding(16.dp)) {
            Box(
                modifier = Modifier.size(34.dp).background(color.copy(alpha = 0.15f), RoundedCornerShape(10.dp)),
                contentAlignment = Alignment.Center
            ) { Icon(icono, contentDescription = null, tint = color, modifier = Modifier.size(18.dp)) }
            Spacer(modifier = Modifier.height(8.dp))
            Text(valor, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color(0xFF222222))
            Text(etiqueta, fontSize = 11.sp, color = Color.Gray)
        }
    }
}
