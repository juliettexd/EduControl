package com.moviles.appsemana07.domain.usecase
data class UsuarioUseCase (
    val agregarUsuario : AgregarUsuarioUseCase,
    val getUsuarios : GetUsuarioUseCase,
    val eliminarUsuario : EliminarUsuarioUseCase,
    val actualizarUsuario : ActualizarUsuarioUseCase,
    val getUsuarioById : GetUsuarioByIdUseCase
)