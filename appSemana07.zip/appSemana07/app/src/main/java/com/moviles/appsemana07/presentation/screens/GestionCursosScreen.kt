package com.moviles.appsemana07.presentation.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.moviles.appsemana07.domain.model.Curso

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GestionCursosScreen(navController: NavController) {
    val fondoDegradado = Brush.linearGradient(colors = listOf(Color(0xFF8A2BE2), Color(0xFF4169E1)))
    var mostrarDialogoNuevo by remember { mutableStateOf(false) }
    var cursoEditar by remember { mutableStateOf<Curso?>(null) }

    Scaffold(
        bottomBar = { BottomNavAdmin(navController = navController, rutaActual = "gestionCursos") }
    ) { paddingValues ->
        Box(modifier = Modifier.fillMaxSize().background(fondoDegradado).padding(paddingValues)) {
            Column(modifier = Modifier.fillMaxSize().padding(24.dp)) {

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Volver", tint = Color.White)
                    }
                    Text("Gestión de Cursos", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.weight(1f))
                    Button(
                        onClick = { mostrarDialogoNuevo = true },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2962FF))
                    ) {
                        Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Nuevo")
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))
                Text("${AdminRepo.cursos.size} cursos activos", color = Color(0xFFE0E0E0), fontSize = 13.sp)
                Spacer(modifier = Modifier.height(16.dp))

                LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(AdminRepo.cursos, key = { it.nombre }) { curso ->
                        val alumnos = AdminRepo.alumnosPorCurso(curso.nombre).size
                        Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.fillMaxWidth()) {
                            Column(modifier = Modifier.padding(20.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(curso.nombre, fontWeight = FontWeight.Bold, color = Color(0xFF2962FF), fontSize = 16.sp, modifier = Modifier.weight(1f))
                                    IconButton(onClick = { cursoEditar = curso }) {
                                        Icon(Icons.Filled.Edit, contentDescription = "Editar", tint = Color(0xFF2962FF))
                                    }
                                }
                                Text("Prof. ${curso.profesor}", fontSize = 13.sp, color = Color(0xFF444444))
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Filled.Group, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("$alumnos alumnos", fontSize = 13.sp, color = Color.Gray)
                                    Spacer(modifier = Modifier.width(14.dp))
                                    Icon(Icons.Filled.Schedule, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(curso.duracion, fontSize = 13.sp, color = Color.Gray)
                                }
                                Text(curso.horario, fontSize = 12.sp, color = Color.Gray)
                            }
                        }
                    }
                }
            }
        }
    }

    if (mostrarDialogoNuevo) {
        NuevoCursoDialog(
            onDismiss = { mostrarDialogoNuevo = false },
            onConfirmar = { nombre, duracion, horario ->
                AdminRepo.agregarCurso(nombre, duracion, horario)
                mostrarDialogoNuevo = false
            }
        )
    }

    cursoEditar?.let { curso ->
        EditarCursoDialog(
            curso = curso,
            onDismiss = { cursoEditar = null },
            onConfirmar = { nombre, profesor ->
                AdminRepo.editarCurso(curso, nombre, profesor)
                cursoEditar = null
            }
        )
    }
}

@Composable
private fun NuevoCursoDialog(onDismiss: () -> Unit, onConfirmar: (String, String, String) -> Unit) {
    var nombre by remember { mutableStateOf("") }
    var duracion by remember { mutableStateOf("") }
    var horario by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Nuevo Curso", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(value = nombre, onValueChange = { nombre = it }, label = { Text("Nombre del curso") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = duracion, onValueChange = { duracion = it }, label = { Text("Duración (ej. 4 meses)") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = horario, onValueChange = { horario = it }, label = { Text("Horario") }, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirmar(nombre, duracion, horario) },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2962FF)),
                enabled = nombre.isNotBlank()
            ) { Text("Crear") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}
@Composable
private fun EditarCursoDialog(curso: Curso, onDismiss: () -> Unit, onConfirmar: (String, String) -> Unit) {
    var nombre by remember { mutableStateOf(curso.nombre) }
    val profesoresDisponibles = AdminRepo.profesoresPorCurso(curso.nombre).map { it.nombre }
        .ifEmpty { listOf(curso.profesor) }
    var profesor by remember { mutableStateOf(curso.profesor) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Editar Curso", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(value = nombre, onValueChange = { nombre = it }, label = { Text("Nombre del curso") }, modifier = Modifier.fillMaxWidth())
                ComboBoxCurso(seleccion = profesor, opciones = profesoresDisponibles, onSeleccion = { profesor = it }, etiqueta = "Profesor asignado")
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirmar(nombre, profesor) },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2962FF)),
                enabled = nombre.isNotBlank()
            ) { Text("Guardar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}
