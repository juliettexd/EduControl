package com.moviles.appsemana07.presentation.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.moviles.appsemana07.domain.model.Alumno

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GestionAlumnosScreen(navController: NavController) {
    val fondoDegradado = Brush.linearGradient(colors = listOf(Color(0xFF8A2BE2), Color(0xFF4169E1)))

    var busqueda by remember { mutableStateOf("") }
    var cursoFiltro by remember { mutableStateOf("Todos") }
    var mostrarDialogoAgregar by remember { mutableStateOf(false) }
    var alumnoEditar by remember { mutableStateOf<Alumno?>(null) }

    val opcionesCurso = listOf("Todos") + AdminRepo.cursos.map { it.nombre }
    val alumnosFiltrados = AdminRepo.alumnos.filter {
        (cursoFiltro == "Todos" || it.curso == cursoFiltro) &&
            (busqueda.isBlank() || it.nombre.contains(busqueda, ignoreCase = true))
    }

    Scaffold(
        bottomBar = { BottomNavAdmin(navController = navController, rutaActual = "gestionAlumnos") }
    ) { paddingValues ->
        Box(modifier = Modifier.fillMaxSize().background(fondoDegradado).padding(paddingValues)) {
            Column(modifier = Modifier.fillMaxSize().padding(24.dp)) {

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Volver", tint = Color.White)
                    }
                    Text("Gestión de Alumnos", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.weight(1f))
                    Button(
                        onClick = { mostrarDialogoAgregar = true },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2962FF))
                    ) {
                        Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Agregar")
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = busqueda,
                    onValueChange = { busqueda = it },
                    label = { Text("Buscar alumno...") },
                    leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(unfocusedContainerColor = Color.White, focusedContainerColor = Color.White)
                )

                Spacer(modifier = Modifier.height(8.dp))

                ComboBoxCurso(
                    seleccion = cursoFiltro,
                    opciones = opcionesCurso,
                    onSeleccion = { cursoFiltro = it }
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row {
                    Text("Total: ${AdminRepo.alumnos.size}", color = Color.White, fontSize = 13.sp)
                    Spacer(modifier = Modifier.width(12.dp))
                    Text("Activos: ${AdminRepo.alumnos.count { it.estado == "Activo" }}", color = Color.White, fontSize = 13.sp)
                }

                Spacer(modifier = Modifier.height(12.dp))

                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(alumnosFiltrados, key = { it.id }) { alumno ->
                        AlumnoCard(
                            alumno = alumno,
                            onEditar = { alumnoEditar = alumno },
                            onEliminar = { AdminRepo.eliminarAlumno(alumno) }
                        )
                    }
                }
            }
        }
    }

    if (mostrarDialogoAgregar) {
        AlumnoDialog(
            titulo = "Agregar Alumno",
            cursos = AdminRepo.cursos.map { it.nombre },
            onDismiss = { mostrarDialogoAgregar = false },
            onConfirmar = { nombre, correo, curso, _ ->
                AdminRepo.agregarAlumno(nombre, correo, curso)
                mostrarDialogoAgregar = false
            }
        )
    }

    alumnoEditar?.let { alumno ->
        AlumnoDialog(
            titulo = "Editar Alumno",
            cursos = AdminRepo.cursos.map { it.nombre },
            nombreInicial = alumno.nombre,
            correoInicial = alumno.correo,
            cursoInicial = alumno.curso,
            estadoInicial = alumno.estado,
            mostrarEstado = true,
            onDismiss = { alumnoEditar = null },
            onConfirmar = { _, _, curso, estado ->
                AdminRepo.actualizarAlumno(alumno, curso, estado)
                alumnoEditar = null
            }
        )
    }
}

@Composable
private fun AlumnoCard(alumno: Alumno, onEditar: () -> Unit, onEliminar: () -> Unit) {
    Card(shape = RoundedCornerShape(14.dp), colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.fillMaxWidth()) {
        Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier.size(44.dp).clip(CircleShape).background(Color(0xFF7C4DFF)),
                contentAlignment = Alignment.Center
            ) {
                Text(alumno.nombre.split(" ").take(2).mapNotNull { it.firstOrNull() }.joinToString(""), color = Color.White, fontWeight = FontWeight.Bold)
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(alumno.nombre, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Spacer(modifier = Modifier.width(8.dp))
                    EstadoBadge(alumno.estado)
                }
                Text(alumno.correo, fontSize = 12.sp, color = Color.Gray)
                Spacer(modifier = Modifier.height(4.dp))
                CursoChip(alumno.curso)
            }
            IconButton(onClick = onEditar) { Icon(Icons.Filled.Edit, contentDescription = "Editar", tint = Color(0xFF2962FF)) }
            IconButton(onClick = onEliminar) { Icon(Icons.Filled.Delete, contentDescription = "Eliminar", tint = Color(0xFFD32F2F)) }
        }
    }
}

@Composable
fun EstadoBadge(estado: String) {
    val color = if (estado == "Activo") Color(0xFF00C853) else Color(0xFF9E9E9E)
    Box(modifier = Modifier.background(color.copy(alpha = 0.15f), RoundedCornerShape(8.dp)).padding(horizontal = 8.dp, vertical = 2.dp)) {
        Text(estado, color = color, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun CursoChip(curso: String) {
    Box(modifier = Modifier.background(Color(0xFF2962FF).copy(alpha = 0.1f), RoundedCornerShape(8.dp)).padding(horizontal = 8.dp, vertical = 3.dp)) {
        Text(curso, color = Color(0xFF2962FF), fontSize = 11.sp, fontWeight = FontWeight.Medium)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ComboBoxCurso(seleccion: String, opciones: List<String>, onSeleccion: (String) -> Unit, etiqueta: String = "Curso / Especialidad") {
    var expandido by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(expanded = expandido, onExpandedChange = { expandido = it }) {
        OutlinedTextField(
            value = seleccion,
            onValueChange = {},
            readOnly = true,
            label = { Text(etiqueta) },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandido) },
            modifier = Modifier.fillMaxWidth().menuAnchor(),
            colors = OutlinedTextFieldDefaults.colors(unfocusedContainerColor = Color.White, focusedContainerColor = Color.White)
        )
        ExposedDropdownMenu(expanded = expandido, onDismissRequest = { expandido = false }) {
            opciones.forEach { opcion ->
                DropdownMenuItem(text = { Text(opcion) }, onClick = { onSeleccion(opcion); expandido = false })
            }
        }
    }
}

@Composable
private fun AlumnoDialog(
    titulo: String,
    cursos: List<String>,
    nombreInicial: String = "",
    correoInicial: String = "",
    cursoInicial: String = "",
    estadoInicial: String = "Activo",
    mostrarEstado: Boolean = false,
    onDismiss: () -> Unit,
    onConfirmar: (String, String, String, String) -> Unit
) {
    var nombre by remember { mutableStateOf(nombreInicial) }
    var correo by remember { mutableStateOf(correoInicial) }
    var curso by remember { mutableStateOf(cursoInicial.ifBlank { cursos.firstOrNull() ?: "" }) }
    var estado by remember { mutableStateOf(estadoInicial) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(titulo, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (!mostrarEstado) {
                    OutlinedTextField(value = nombre, onValueChange = { nombre = it }, label = { Text("Nombre") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = correo, onValueChange = { correo = it }, label = { Text("Correo") }, modifier = Modifier.fillMaxWidth())
                }
                ComboBoxCurso(seleccion = curso, opciones = cursos, onSeleccion = { curso = it })
                if (mostrarEstado) {
                    ComboBoxCurso(seleccion = estado, opciones = listOf("Activo", "Inactivo"), onSeleccion = { estado = it }, etiqueta = "Estado")
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirmar(nombre, correo, curso, estado) },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2962FF)),
                enabled = mostrarEstado || nombre.isNotBlank()
            ) { Text("Guardar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}
