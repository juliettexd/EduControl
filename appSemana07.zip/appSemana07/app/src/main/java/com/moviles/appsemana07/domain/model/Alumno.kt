package com.moviles.appsemana07.domain.model

data class Alumno(
    val id: Int,
    val nombre: String,
    val correo: String,
    val curso: String,
    val estado: String = "Activo" // Activo / Inactivo
)
