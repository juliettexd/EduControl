package com.moviles.appsemana07.presentation.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.moviles.appsemana07.presentation.screens.AdminMenuScreen
import com.moviles.appsemana07.presentation.screens.AlumnoDashboardScreen
import com.moviles.appsemana07.presentation.screens.AlumnosProfesorScreen
import com.moviles.appsemana07.presentation.screens.AsistenciaProfesorScreen
import com.moviles.appsemana07.presentation.screens.AvisosAlumnoScreen
import com.moviles.appsemana07.presentation.screens.AvisosProfesorScreen
import com.moviles.appsemana07.presentation.screens.ConfiguracionAdminScreen
import com.moviles.appsemana07.presentation.screens.ConfiguracionAlumnoScreen
import com.moviles.appsemana07.presentation.screens.ConfiguracionProfesorScreen
import com.moviles.appsemana07.presentation.screens.CursosAlumnoScreen
import com.moviles.appsemana07.presentation.screens.CursosProfesorScreen
import com.moviles.appsemana07.presentation.screens.GestionAlumnosScreen
import com.moviles.appsemana07.presentation.screens.GestionCursosScreen
import com.moviles.appsemana07.presentation.screens.GestionMatriculasScreen
import com.moviles.appsemana07.presentation.screens.GestionProfesoresScreen
import com.moviles.appsemana07.presentation.screens.HorarioAlumnoScreen
import com.moviles.appsemana07.presentation.screens.MensajesProfesorScreen
import com.moviles.appsemana07.presentation.viewmodel.UsuarioViewModel
import com.moviles.appsemana07.presentation.screens.LoginScreen
import com.moviles.appsemana07.presentation.screens.NotasAlumnoScreen
import com.moviles.appsemana07.presentation.screens.NotasProfesorScreen
import com.moviles.appsemana07.presentation.screens.PerfilAdminScreen
import com.moviles.appsemana07.presentation.screens.PerfilAlumnoScreen
import com.moviles.appsemana07.presentation.screens.PerfilProfesorScreen
import com.moviles.appsemana07.presentation.screens.ProfesorMenuScreen
import com.moviles.appsemana07.presentation.screens.RegistrarAsistenciaScreen
import com.moviles.appsemana07.presentation.screens.ReportesAdminScreen

@Composable
fun NavGraph(vm: UsuarioViewModel){
    val navController = rememberNavController()
    NavHost(
        navController = navController,
        startDestination = "login"
    ){
        composable("login"){
            LoginScreen(navController)
        }

        composable("profesor"){
            ProfesorMenuScreen(navController)
        }
        composable("cursosProfesor") {
            CursosProfesorScreen(navController)
        }
        composable("alumnosProfesor") {
            AlumnosProfesorScreen(navController)
        }
        composable("notasProfesor") {
            NotasProfesorScreen(navController)
        }
        composable("avisosProfesor") {
            AvisosProfesorScreen(navController)
        }
        composable("perfilProfesor") {
            PerfilProfesorScreen(navController)
        }
        composable("configuracionProfesor") {
            ConfiguracionProfesorScreen(navController)
        }
        composable("asistenciaProfesor") {
            AsistenciaProfesorScreen(navController)
        }
        composable("mensajesProfesor") {
            MensajesProfesorScreen(navController)
        }
        composable(
            route = "registrarAsistencia/{cursoId}",
            arguments = listOf(navArgument("cursoId") { type = NavType.IntType })
        ) { backStackEntry ->
            val cursoId = backStackEntry.arguments?.getInt("cursoId") ?: 0
            RegistrarAsistenciaScreen(navController, cursoId)
        }
        composable("alumno") {
            AlumnoDashboardScreen(navController)
        }
        composable("cursosAlumno") {
            CursosAlumnoScreen(navController)
        }
        composable("horarioAlumno") {
            HorarioAlumnoScreen(navController)
        }
        composable("notasAlumno") {
            NotasAlumnoScreen(navController)
        }
        composable("perfilAlumno") {
            PerfilAlumnoScreen(navController)
        }
        composable("configuracionAlumno") {
            ConfiguracionAlumnoScreen(navController)
        }
        composable("avisosAlumno") {
            AvisosAlumnoScreen(navController)
        }

        composable("adminMenu") {
            AdminMenuScreen(navController)
        }
        composable("gestionAlumnos") {
            GestionAlumnosScreen(navController)
        }
        composable("gestionProfesores") {
            GestionProfesoresScreen(navController)
        }
        composable("gestionCursos") {
            GestionCursosScreen(navController)
        }
        composable("gestionMatriculas") {
            GestionMatriculasScreen(navController)
        }
        composable("reportesScreen") {
            ReportesAdminScreen(navController)
        }
        composable("perfilAdmin") {
            PerfilAdminScreen(navController)
        }
        composable("configuracionAdmin") {
            ConfiguracionAdminScreen(navController)
        }
    }
}
