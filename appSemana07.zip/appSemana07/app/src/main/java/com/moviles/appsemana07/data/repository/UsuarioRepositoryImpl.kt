package com.moviles.appsemana07.data.repository

import com.moviles.appsemana07.data.local.dao.UsuarioDao
import com.moviles.appsemana07.data.mapper.UsuarioMapper
import com.moviles.appsemana07.domain.model.Usuario
import com.moviles.appsemana07.domain.repository.UsuarioRepository

class UsuarioRepositoryImpl(private val dao: UsuarioDao) : UsuarioRepository {
    override suspend fun insertar(usuario: Usuario) {
        dao.agregar(UsuarioMapper.toEntity(usuario))
    }

    override suspend fun actualizar(usuario: Usuario) {
        dao.actualizar(UsuarioMapper.toEntity(usuario))
    }

    override suspend fun eliminar(usuario: Usuario) {
        dao.eliminar(UsuarioMapper.toEntity(usuario))
    }

    override suspend fun getAll(): List<Usuario> =
        dao.getAll().map { UsuarioMapper.toDomain(it) }


    override suspend fun getById(id: Int): Usuario =
        dao.getById(id).let { UsuarioMapper.toDomain(it) }
}