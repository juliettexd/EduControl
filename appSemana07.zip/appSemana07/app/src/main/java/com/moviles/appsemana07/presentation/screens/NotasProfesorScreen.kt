package com.moviles.appsemana07.presentation.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotasProfesorScreen(navController: NavController) {
    val fondoDegradado = Brush.linearGradient(colors = listOf(Color(0xFF8A2BE2), Color(0xFF4169E1)))
    var cursoSeleccionado by remember { mutableStateOf(ProfesorRepo.cursos.first()) }
    var menuAbierto by remember { mutableStateOf(false) }

    Scaffold(
        bottomBar = { BottomNavProfesor(navController = navController, rutaActual = "notasProfesor") }
    ) { padding ->
        Box(modifier = Modifier.fillMaxSize().background(fondoDegradado).padding(padding)) {
            Column(modifier = Modifier.fillMaxSize().padding(24.dp)) {
                EncabezadoPestana(titulo = "Registrar Notas", navController = navController, mostrarVolver = true)
                Spacer(modifier = Modifier.height(16.dp))

                Text("Curso", color = Color(0xFFE0E0E0), fontSize = 13.sp)
                Spacer(modifier = Modifier.height(6.dp))
                Box {
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        modifier = Modifier.fillMaxWidth().clickable { menuAbierto = true }
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(cursoSeleccionado.nombre, fontWeight = FontWeight.Bold, color = Color(0xFF222222))
                            Icon(Icons.Filled.ArrowDropDown, contentDescription = null, tint = Color.Gray)
                        }
                    }
                    DropdownMenu(expanded = menuAbierto, onDismissRequest = { menuAbierto = false }) {
                        ProfesorRepo.cursos.forEach { curso ->
                            DropdownMenuItem(text = { Text(curso.nombre) }, onClick = {
                                cursoSeleccionado = curso
                                menuAbierto = false
                            })
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                val promedioGeneral = cursoSeleccionado.alumnos.map { it.promedio }.average()
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(4.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(modifier = Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier.size(42.dp).background(Color(0xFFFFF3E0), RoundedCornerShape(12.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Filled.EmojiEvents, contentDescription = null, tint = Color(0xFFFF9800))
                        }
                        Spacer(modifier = Modifier.width(14.dp))
                        Column {
                            Text("Promedio General", fontSize = 13.sp, color = Color.Gray)
                            Text(
                                text = String.format("%.1f", if (promedioGeneral.isNaN()) 0.0 else promedioGeneral),
                                fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color(0xFF2962FF)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(cursoSeleccionado.alumnos, key = { it.id }) { alumno ->
                        val guardado = cursoSeleccionado.notasGuardadas.value
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            elevation = CardDefaults.cardElevation(4.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(alumno.nombre, fontWeight = FontWeight.Bold, color = Color(0xFF222222))
                                Text(
                                    "Promedio: ${String.format("%.1f", alumno.promedio)}",
                                    fontSize = 12.sp, color = Color.Gray
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    CampoNota("Examen 1", alumno.examen1, guardado) { alumno.examen1 = it }
                                    CampoNota("Examen 2", alumno.examen2, guardado) { alumno.examen2 = it }
                                    CampoNota("Examen 3", alumno.examen3, guardado) { alumno.examen3 = it }
                                }
                            }
                        }
                    }
                    item { Spacer(modifier = Modifier.height(4.dp)) }
                }

                Spacer(modifier = Modifier.height(8.dp))
                Button(
                    onClick = { cursoSeleccionado.notasGuardadas.value = !cursoSeleccionado.notasGuardadas.value },
                    modifier = Modifier.fillMaxWidth().height(50.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6A3DE8))
                ) {
                    Text(
                        if (cursoSeleccionado.notasGuardadas.value) "Editar Notas" else "Guardar Notas",
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
private fun RowScope.CampoNota(etiqueta: String, valor: Int, soloLectura: Boolean, onChange: (Int) -> Unit) {
    Column(modifier = Modifier.weight(1f)) {
        Text(etiqueta, fontSize = 11.sp, color = Color.Gray)
        Spacer(modifier = Modifier.height(4.dp))
        OutlinedTextField(
            value = if (valor == 0) "" else valor.toString(),
            onValueChange = { texto ->
                val numero = texto.filter { it.isDigit() }.take(2)
                onChange(numero.toIntOrNull() ?: 0)
            },
            enabled = !soloLectura,
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            textStyle = androidx.compose.ui.text.TextStyle(fontSize = 14.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.fillMaxWidth()
        )
    }
}
