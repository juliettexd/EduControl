package com.moviles.appsemana07.presentation.state

import com.moviles.appsemana07.domain.model.Usuario

data class UsuarioUiState (
    val usuarios: List<Usuario> = emptyList(),
    val isLoading: Boolean = false,
    val search: String = ""
)