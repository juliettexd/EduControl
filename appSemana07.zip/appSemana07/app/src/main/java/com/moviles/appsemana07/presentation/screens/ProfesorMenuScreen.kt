package com.moviles.appsemana07.presentation.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfesorMenuScreen(navController: NavController) {
    val fondoDegradado = Brush.linearGradient(colors = listOf(Color(0xFF8A2BE2), Color(0xFF4169E1)))

    Scaffold(
        bottomBar = { BottomNavProfesor(navController = navController, rutaActual = "profesor") }
    ) { padding ->
        Box(modifier = Modifier.fillMaxSize().background(fondoDegradado).padding(padding)) {
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(24.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Panel del Profesor", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                    Text("Prof. ${ProfesorRepo.nombreProfesor}", color = Color(0xFFE0E0E0), fontSize = 14.sp)
                }
                item {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        TarjetaEstadisticaProfesor(
                            modifier = Modifier.weight(1f),
                            icono = Icons.Filled.MenuBook,
                            valor = "${ProfesorRepo.cursos.size}",
                            etiqueta = "Mis Cursos",
                            color = Color(0xFF2962FF)
                        ) {
                            navController.navigate("cursosProfesor") { popUpTo("profesor"); launchSingleTop = true }
                        }
                        TarjetaEstadisticaProfesor(
                            modifier = Modifier.weight(1f),
                            icono = Icons.Filled.Group,
                            valor = "${ProfesorRepo.totalAlumnos}",
                            etiqueta = "Total Alumnos",
                            color = Color(0xFFAA00FF)
                        ) {
                            navController.navigate("alumnosProfesor")
                        }
                    }
                }
                item {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        TarjetaEstadisticaProfesor(
                            modifier = Modifier.weight(1f),
                            icono = Icons.Filled.HowToReg,
                            valor = "${ProfesorRepo.porcentajeAsistenciaHoy}%",
                            etiqueta = "Asistencia Hoy",
                            color = Color(0xFF00B4A6)
                        ) {
                            navController.navigate("asistenciaProfesor")
                        }
                        TarjetaEstadisticaProfesor(
                            modifier = Modifier.weight(1f),
                            icono = Icons.Filled.Forum,
                            valor = "${ProfesorRepo.mensajes.size}",
                            etiqueta = "Mensajes",
                            color = Color(0xFFFF6D00)
                        ) {
                            navController.navigate("mensajesProfesor")
                        }
                    }
                }

                item {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Mis Cursos", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                }

                items(ProfesorRepo.cursos) { curso ->
                    TarjetaBlancaProfesor(
                        onClick = { navController.navigate("cursosProfesor") { popUpTo("profesor"); launchSingleTop = true } }
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Top
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(curso.nombre, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color(0xFF222222))
                                Spacer(modifier = Modifier.height(4.dp))
                                Box(
                                    modifier = Modifier
                                        .background(Color(0xFFE3F2FD), RoundedCornerShape(50))
                                        .padding(horizontal = 10.dp, vertical = 3.dp)
                                ) {
                                    Text(curso.proximoTema, fontSize = 11.sp, color = Color(0xFF2962FF))
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.Group, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("${curso.totalAlumnos} alumnos", fontSize = 12.sp, color = Color.Gray)
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.Schedule, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(curso.horarioTexto, fontSize = 12.sp, color = Color.Gray)
                            }
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Progreso del curso", fontSize = 12.sp, color = Color.Gray)
                            Text("${curso.progreso}%", fontSize = 12.sp, color = Color.Gray)
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        LinearProgressIndicator(
                            progress = curso.progreso / 100f,
                            modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(50)),
                            color = Color(0xFF6A3DE8),
                            trackColor = Color(0xFFEFEFEF)
                        )
                    }
                }

                item { Spacer(modifier = Modifier.height(8.dp)) }
            }
        }
    }
}
