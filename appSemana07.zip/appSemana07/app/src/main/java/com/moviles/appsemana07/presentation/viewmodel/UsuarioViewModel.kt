package com.moviles.appsemana07.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.moviles.appsemana07.domain.model.Usuario
import com.moviles.appsemana07.domain.usecase.UsuarioUseCase
import com.moviles.appsemana07.presentation.state.UsuarioUiEvent
import com.moviles.appsemana07.presentation.state.UsuarioUiState
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import androidx.lifecycle.viewModelScope
import com.moviles.appsemana07.di.AppModule

class UsuarioViewModel(private val usuarioCases : UsuarioUseCase): ViewModel() {
    private val _uiState = MutableStateFlow(UsuarioUiState())
    val uiState : StateFlow<UsuarioUiState> = _uiState
    private val _event = MutableSharedFlow<UsuarioUiEvent>()
    val event = _event
    private var allUsuarios = listOf<Usuario>()
    private var isProcessing = false
    init {
        cargarUsuarios()
    }
    fun cargarUsuarios(){
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            try {
                allUsuarios = usuarioCases.getUsuarios()
                _uiState.update {
                    it.copy(usuarios = allUsuarios, isLoading = false)
                }
            }catch (e: Exception){
                _uiState.update { it.copy(isLoading = false) }
                _event.emit(UsuarioUiEvent.ShowSnackbar(e.message ?: "Ocurrio un error"))
            }
        }
    }
    fun agregarUsuario(usuario: Usuario){
        if(isProcessing) return
        viewModelScope.launch {
            isProcessing = true
            try {
                _uiState.update { it.copy(isLoading = true) }
                usuarioCases.agregarUsuario(usuario)
                cargarUsuarios()
                _event.emit(UsuarioUiEvent.NavigateBack)
            }catch (e: Exception){
                _event.emit(UsuarioUiEvent.ShowSnackbar(e.message ?: "Error"))
            }finally {
                isProcessing = false
                _uiState.update { it.copy(isLoading = false) }
            }
        }
    }

    private val _anunciosNube = androidx.compose.runtime.mutableStateOf<List<com.moviles.appsemana07.data.remote.NetworkAnuncio>>(emptyList())
    val anunciosNube: androidx.compose.runtime.State<List<com.moviles.appsemana07.data.remote.NetworkAnuncio>> = _anunciosNube

    private val _usuariosNube = androidx.compose.runtime.mutableStateOf<List<com.moviles.appsemana07.data.remote.NetworkUsuario>>(emptyList())
    val usuariosNube: androidx.compose.runtime.State<List<com.moviles.appsemana07.data.remote.NetworkUsuario>> = _usuariosNube

    fun registrarUsuarioEnAWS(nombre: String, correo: String, rol: String) {
        viewModelScope.launch {
            try {
                val nuevoUsuario = com.moviles.appsemana07.data.remote.NetworkUsuario(nombre, correo, rol)
                com.moviles.appsemana07.di.AppModule.apiService.registrarUsuario(nuevoUsuario)
                cargarUsuariosDesdeAWS()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun publicarAnuncioEnAWS(titulo: String, contenido: String, autor: String) {
        viewModelScope.launch {
            try {
                val nuevoAnuncio = com.moviles.appsemana07.data.remote.NetworkAnuncio(titulo, contenido, autor)
                com.moviles.appsemana07.di.AppModule.apiService.publicarAnuncio(nuevoAnuncio)
                cargarAnunciosDesdeAWS()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun cargarAnunciosDesdeAWS() {
        viewModelScope.launch {
            try {
                _anunciosNube.value = com.moviles.appsemana07.di.AppModule.apiService.obtenerAnuncios()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun cargarUsuariosDesdeAWS() {
        viewModelScope.launch {
            try {
                _usuariosNube.value = com.moviles.appsemana07.di.AppModule.apiService.obtenerUsuarios()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
}