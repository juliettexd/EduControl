package com.moviles.appsemana07.domain.model

data class Profesor(
    val id: Int,
    val nombre: String,
    val correo: String,
    val telefono: String,
    val especialidad: String,
    val horario: String,
    val asistencia: Int = 90
)
