package com.moviles.appsemana07.presentation.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HorarioAlumnoScreen(navController: NavController) {
    val fondoDegradado = Brush.linearGradient(colors = listOf(Color(0xFF8A2BE2), Color(0xFF4169E1)))
    val diasOrdenados = listOf("Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo")

    Scaffold(
        bottomBar = { BottomNavAlumno(navController = navController, rutaActual = "horarioAlumno") }
    ) { padding ->
        Box(modifier = Modifier.fillMaxSize().background(fondoDegradado).padding(padding)) {
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(24.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    EncabezadoPestana(titulo = "Mi Horario", navController = navController, mostrarVolver = true)
                }

                item {
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        elevation = CardDefaults.cardElevation(4.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(20.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("Mi Asistencia", fontSize = 13.sp, color = Color.Gray)
                                Text(
                                    "${AlumnoRepo.porcentajeAsistencia}%",
                                    fontSize = 26.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF2E7D32)
                                )
                            }
                            Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = Color(0xFF2E7D32), modifier = Modifier.size(32.dp))
                        }
                    }
                }

                item {
                    Text("Horario Semanal", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                }
                diasOrdenados.forEach { dia ->
                    val clasesDelDia = AlumnoRepo.horario.filter { it.dia == dia }
                    if (clasesDelDia.isNotEmpty()) {
                        item {
                            Text(dia, color = Color(0xFFEDE7F6), fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        }
                        items(clasesDelDia) { clase ->
                            Card(
                                shape = RoundedCornerShape(14.dp),
                                colors = CardDefaults.cardColors(containerColor = Color.White),
                                elevation = CardDefaults.cardElevation(3.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(16.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Filled.Schedule, contentDescription = null, tint = Color(0xFF6A3DE8))
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(clase.curso, fontWeight = FontWeight.Bold, color = Color(0xFF222222))
                                        Text("${clase.horaInicio} - ${clase.horaFin} · ${clase.aula}", fontSize = 12.sp, color = Color.Gray)
                                    }
                                }
                            }
                        }
                    }
                }

                item {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Asistencia por Fecha", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                }
                items(AlumnoRepo.asistencia.reversed()) { registro ->
                    val (colorFondo, colorTexto) = when (registro.estado) {
                        EstadoAsistencia.A_TIEMPO -> Color(0xFFE8F5E9) to Color(0xFF2E7D32)
                        EstadoAsistencia.TARDE -> Color(0xFFFFF3E0) to Color(0xFFEF6C00)
                        EstadoAsistencia.FALTA -> Color(0xFFFFEBEE) to Color(0xFFC62828)
                    }
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        elevation = CardDefaults.cardElevation(3.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(registro.curso, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFF222222))
                                Text(registro.fecha, fontSize = 12.sp, color = Color.Gray)
                            }
                            Box(
                                modifier = Modifier
                                    .background(colorFondo, RoundedCornerShape(50))
                                    .padding(horizontal = 12.dp, vertical = 5.dp)
                            ) {
                                Text(registro.estado.etiqueta, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = colorTexto)
                            }
                        }
                    }
                }
                item { Spacer(modifier = Modifier.height(4.dp)) }
            }
        }
    }
}
